#
# SQL Export
# Created by Querious (300050)
# Created: September 2, 2020 at 5:55:21 PM EDT
# Encoding: Unicode (UTF-8)
#


SET @ORIG_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS;
SET FOREIGN_KEY_CHECKS = 0;

SET @ORIG_UNIQUE_CHECKS = @@UNIQUE_CHECKS;
SET UNIQUE_CHECKS = 0;

SET @ORIG_TIME_ZONE = @@TIME_ZONE;
SET TIME_ZONE = '+00:00';

SET @ORIG_SQL_MODE = @@SQL_MODE;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';



DROP TABLE IF EXISTS `widgets`;
DROP TABLE IF EXISTS `volumefolders`;
DROP TABLE IF EXISTS `volumes`;
DROP TABLE IF EXISTS `userpreferences`;
DROP TABLE IF EXISTS `userpermissions_users`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `userpermissions_usergroups`;
DROP TABLE IF EXISTS `userpermissions`;
DROP TABLE IF EXISTS `usergroups_users`;
DROP TABLE IF EXISTS `usergroups`;
DROP TABLE IF EXISTS `tokens`;
DROP TABLE IF EXISTS `templatecachequeries`;
DROP TABLE IF EXISTS `templatecacheelements`;
DROP TABLE IF EXISTS `templatecaches`;
DROP TABLE IF EXISTS `tags`;
DROP TABLE IF EXISTS `taggroups`;
DROP TABLE IF EXISTS `systemmessages`;
DROP TABLE IF EXISTS `supertableblocks`;
DROP TABLE IF EXISTS `supertableblocktypes`;
DROP TABLE IF EXISTS `structureelements`;
DROP TABLE IF EXISTS `structures`;
DROP TABLE IF EXISTS `stc_1_images`;
DROP TABLE IF EXISTS `sites`;
DROP TABLE IF EXISTS `sitegroups`;
DROP TABLE IF EXISTS `shunnedmessages`;
DROP TABLE IF EXISTS `sessions`;
DROP TABLE IF EXISTS `sequences`;
DROP TABLE IF EXISTS `sections_sites`;
DROP TABLE IF EXISTS `sections`;
DROP TABLE IF EXISTS `searchindex`;
DROP TABLE IF EXISTS `resourcepaths`;
DROP TABLE IF EXISTS `relations`;
DROP TABLE IF EXISTS `queue`;
DROP TABLE IF EXISTS `migrations`;
DROP TABLE IF EXISTS `plugins`;
DROP TABLE IF EXISTS `matrixcontent_modules`;
DROP TABLE IF EXISTS `matrixblocks`;
DROP TABLE IF EXISTS `matrixblocktypes`;
DROP TABLE IF EXISTS `info`;
DROP TABLE IF EXISTS `globalsets`;
DROP TABLE IF EXISTS `fieldlayoutfields`;
DROP TABLE IF EXISTS `fields`;
DROP TABLE IF EXISTS `fieldlayouttabs`;
DROP TABLE IF EXISTS `fieldgroups`;
DROP TABLE IF EXISTS `entryversions`;
DROP TABLE IF EXISTS `entrytypes`;
DROP TABLE IF EXISTS `fieldlayouts`;
DROP TABLE IF EXISTS `entrydrafts`;
DROP TABLE IF EXISTS `entries`;
DROP TABLE IF EXISTS `elements_sites`;
DROP TABLE IF EXISTS `elementindexsettings`;
DROP TABLE IF EXISTS `deprecationerrors`;
DROP TABLE IF EXISTS `craftidtokens`;
DROP TABLE IF EXISTS `content`;
DROP TABLE IF EXISTS `categorygroups_sites`;
DROP TABLE IF EXISTS `categories`;
DROP TABLE IF EXISTS `categorygroups`;
DROP TABLE IF EXISTS `assettransforms`;
DROP TABLE IF EXISTS `assettransformindex`;
DROP TABLE IF EXISTS `assets`;
DROP TABLE IF EXISTS `elements`;
DROP TABLE IF EXISTS `assetindexdata`;


CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assetindexdata_sessionId_volumeId_idx` (`sessionId`,`volumeId`),
  KEY `assetindexdata_volumeId_idx` (`volumeId`),
  CONSTRAINT `assetindexdata_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `elements_dateDeleted_idx` (`dateDeleted`),
  KEY `elements_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `elements_type_idx` (`type`),
  KEY `elements_enabled_idx` (`enabled`),
  KEY `elements_archived_dateCreated_idx` (`archived`,`dateCreated`),
  CONSTRAINT `elements_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;


CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assets_filename_folderId_idx` (`filename`,`folderId`),
  KEY `assets_folderId_idx` (`folderId`),
  KEY `assets_volumeId_idx` (`volumeId`),
  CONSTRAINT `assets_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assettransformindex_volumeId_assetId_location_idx` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;


CREATE TABLE `assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categorygroups_name_idx` (`name`),
  KEY `categorygroups_handle_idx` (`handle`),
  KEY `categorygroups_structureId_idx` (`structureId`),
  KEY `categorygroups_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `categorygroups_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categories_groupId_idx` (`groupId`),
  KEY `categories_parentId_fk` (`parentId`),
  CONSTRAINT `categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorygroups_sites_groupId_siteId_unq_idx` (`groupId`,`siteId`),
  KEY `categorygroups_sites_siteId_idx` (`siteId`),
  CONSTRAINT `categorygroups_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categorygroups_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_contentEntry` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `content_siteId_idx` (`siteId`),
  KEY `content_title_idx` (`title`),
  CONSTRAINT `content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `content_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;


CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craftidtokens_userId_fk` (`userId`),
  CONSTRAINT `craftidtokens_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


CREATE TABLE `elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elements_sites_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `elements_sites_siteId_idx` (`siteId`),
  KEY `elements_sites_slug_siteId_idx` (`slug`,`siteId`),
  KEY `elements_sites_enabled_idx` (`enabled`),
  KEY `elements_sites_uri_siteId_idx` (`uri`,`siteId`),
  CONSTRAINT `elements_sites_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;


CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entries_postDate_idx` (`postDate`),
  KEY `entries_expiryDate_idx` (`expiryDate`),
  KEY `entries_authorId_idx` (`authorId`),
  KEY `entries_sectionId_idx` (`sectionId`),
  KEY `entries_typeId_idx` (`typeId`),
  KEY `entries_parentId_fk` (`parentId`),
  CONSTRAINT `entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `entrydrafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrydrafts_sectionId_idx` (`sectionId`),
  KEY `entrydrafts_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `entrydrafts_siteId_idx` (`siteId`),
  KEY `entrydrafts_creatorId_idx` (`creatorId`),
  CONSTRAINT `entrydrafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entrydrafts_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouts_dateDeleted_idx` (`dateDeleted`),
  KEY `fieldlayouts_type_idx` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;


CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleLabel` varchar(255) DEFAULT 'Title',
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrytypes_name_sectionId_idx` (`name`,`sectionId`),
  KEY `entrytypes_handle_sectionId_idx` (`handle`,`sectionId`),
  KEY `entrytypes_sectionId_idx` (`sectionId`),
  KEY `entrytypes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `entrytypes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


CREATE TABLE `entryversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `siteId` int(11) NOT NULL,
  `num` smallint(6) unsigned NOT NULL,
  `notes` text,
  `data` mediumtext NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entryversions_sectionId_idx` (`sectionId`),
  KEY `entryversions_entryId_siteId_idx` (`entryId`,`siteId`),
  KEY `entryversions_siteId_idx` (`siteId`),
  KEY `entryversions_creatorId_idx` (`creatorId`),
  CONSTRAINT `entryversions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entryversions_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entryversions_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entryversions_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;


CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayouttabs_layoutId_idx` (`layoutId`),
  CONSTRAINT `fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;


CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `fields_groupId_idx` (`groupId`),
  KEY `fields_context_idx` (`context`),
  CONSTRAINT `fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;


CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayoutfields_tabId_idx` (`tabId`),
  KEY `fieldlayoutfields_fieldId_idx` (`fieldId`),
  CONSTRAINT `fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;


CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `globalsets_name_idx` (`name`),
  KEY `globalsets_handle_idx` (`handle`),
  KEY `globalsets_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `config` mediumtext,
  `configMap` mediumtext,
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `matrixblocktypes_fieldId_idx` (`fieldId`),
  KEY `matrixblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `matrixblocks_ownerId_idx` (`ownerId`),
  KEY `matrixblocks_fieldId_idx` (`fieldId`),
  KEY `matrixblocks_typeId_idx` (`typeId`),
  KEY `matrixblocks_sortOrder_idx` (`sortOrder`),
  KEY `matrixblocks_ownerSiteId_idx` (`ownerSiteId`),
  CONSTRAINT `matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `matrixcontent_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_imagesRow_heading` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_modules_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_modules_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_modules_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_modules_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plugins_handle_unq_idx` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `type` enum('app','plugin','content') NOT NULL DEFAULT 'app',
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `migrations_pluginId_idx` (`pluginId`),
  KEY `migrations_type_pluginId_idx` (`type`,`pluginId`),
  CONSTRAINT `migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8;


CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `queue_fail_timeUpdated_timePushed_idx` (`fail`,`timeUpdated`,`timePushed`),
  KEY `queue_fail_timeUpdated_delay_idx` (`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `relations_fieldId_sourceId_sourceSiteId_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `relations_sourceId_idx` (`sourceId`),
  KEY `relations_targetId_idx` (`targetId`),
  KEY `relations_sourceSiteId_idx` (`sourceSiteId`),
  CONSTRAINT `relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;


CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagateEntries` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sections_handle_idx` (`handle`),
  KEY `sections_name_idx` (`name`),
  KEY `sections_structureId_idx` (`structureId`),
  KEY `sections_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sections_sites_sectionId_siteId_unq_idx` (`sectionId`,`siteId`),
  KEY `sections_sites_siteId_idx` (`siteId`),
  CONSTRAINT `sections_sites_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sections_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sessions_uid_idx` (`uid`),
  KEY `sessions_token_idx` (`token`),
  KEY `sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `sessions_userId_idx` (`userId`),
  CONSTRAINT `sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;


CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sitegroups_name_idx` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sites_dateDeleted_idx` (`dateDeleted`),
  KEY `sites_handle_idx` (`handle`),
  KEY `sites_sortOrder_idx` (`sortOrder`),
  KEY `sites_groupId_fk` (`groupId`),
  CONSTRAINT `sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


CREATE TABLE `stc_1_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `stc_1_images_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `stc_1_images_siteId_fk` (`siteId`),
  CONSTRAINT `stc_1_images_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stc_1_images_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `structures_dateDeleted_idx` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `structureelements_root_idx` (`root`),
  KEY `structureelements_lft_idx` (`lft`),
  KEY `structureelements_rgt_idx` (`rgt`),
  KEY `structureelements_level_idx` (`level`),
  KEY `structureelements_elementId_idx` (`elementId`),
  CONSTRAINT `structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `supertableblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `supertableblocktypes_fieldId_idx` (`fieldId`),
  KEY `supertableblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `supertableblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


CREATE TABLE `supertableblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `ownerSiteId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `supertableblocks_ownerId_idx` (`ownerId`),
  KEY `supertableblocks_fieldId_idx` (`fieldId`),
  KEY `supertableblocks_typeId_idx` (`typeId`),
  KEY `supertableblocks_sortOrder_idx` (`sortOrder`),
  KEY `supertableblocks_ownerSiteId_idx` (`ownerSiteId`),
  CONSTRAINT `supertableblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `supertableblocks_ownerSiteId_fk` FOREIGN KEY (`ownerSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `supertableblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `supertableblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `systemmessages_key_language_unq_idx` (`key`,`language`),
  KEY `systemmessages_language_idx` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `taggroups_name_idx` (`name`),
  KEY `taggroups_handle_idx` (`handle`),
  KEY `taggroups_dateDeleted_idx` (`dateDeleted`),
  KEY `taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tags_groupId_idx` (`groupId`),
  CONSTRAINT `tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tags_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_path_idx` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_idx` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `templatecaches_siteId_idx` (`siteId`),
  CONSTRAINT `templatecaches_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `templatecacheelements_cacheId_idx` (`cacheId`),
  KEY `templatecacheelements_elementId_idx` (`elementId`),
  CONSTRAINT `templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecachequeries_cacheId_idx` (`cacheId`),
  KEY `templatecachequeries_type_idx` (`type`),
  CONSTRAINT `templatecachequeries_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tokens_token_unq_idx` (`token`),
  KEY `tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;


CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_handle_unq_idx` (`handle`),
  UNIQUE KEY `usergroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `usergroups_users_userId_idx` (`userId`),
  CONSTRAINT `usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `userpermissions_usergroups_groupId_idx` (`groupId`),
  CONSTRAINT `userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `users_uid_idx` (`uid`),
  KEY `users_verificationCode_idx` (`verificationCode`),
  KEY `users_email_idx` (`email`),
  KEY `users_username_idx` (`username`),
  KEY `users_photoId_fk` (`photoId`),
  CONSTRAINT `users_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_photoId_fk` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `userpermissions_users_userId_idx` (`userId`),
  CONSTRAINT `userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `userpreferences_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `settings` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `volumes_name_idx` (`name`),
  KEY `volumes_handle_idx` (`handle`),
  KEY `volumes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `volumes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `volumes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `volumefolders_name_parentId_volumeId_unq_idx` (`name`,`parentId`,`volumeId`),
  KEY `volumefolders_parentId_idx` (`parentId`),
  KEY `volumefolders_volumeId_idx` (`volumeId`),
  CONSTRAINT `volumefolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `volumefolders_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `widgets_userId_idx` (`userId`),
  CONSTRAINT `widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;




LOCK TABLES `assetindexdata` WRITE;
UNLOCK TABLES;


LOCK TABLES `elements` WRITE;
INSERT INTO `elements` (`id`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES 
	(1,NULL,'craft\\elements\\User',1,0,'2019-05-23 15:26:20','2019-05-23 15:26:20',NULL,'1a807b5a-b0ea-463e-bc46-490814986a7a'),
	(2,1,'craft\\elements\\Entry',1,0,'2019-06-17 17:16:56','2020-01-03 17:09:04',NULL,'0f0416bb-508e-496c-b646-9ab4944f8408'),
	(3,2,'craft\\elements\\Entry',1,0,'2019-08-19 16:00:26','2019-08-19 16:15:47','2019-08-19 17:36:22','8ba0478a-e8be-4398-9831-928fe2605b28'),
	(4,NULL,'craft\\elements\\Asset',1,0,'2019-08-19 16:09:10','2019-08-19 16:09:10','2019-08-19 18:01:16','166a0316-51ba-47f8-8723-78d762cb87f3'),
	(5,2,'craft\\elements\\Entry',1,0,'2019-08-19 17:37:50','2019-08-19 17:49:41','2019-08-19 17:51:39','fce232a9-6f47-4a79-b504-45709795afa5'),
	(6,NULL,'craft\\elements\\Asset',1,0,'2019-08-19 17:49:32','2019-08-19 17:49:32','2019-08-19 18:01:08','0dbcd5b4-f897-4be1-97ea-63cb00b74756'),
	(7,2,'craft\\elements\\Entry',1,0,'2019-08-19 17:52:29','2019-08-19 17:54:47','2019-08-19 17:55:15','32f43ec6-828f-43ce-a5ca-c2235cea072b'),
	(8,2,'craft\\elements\\Entry',0,0,'2019-08-19 17:56:25','2019-08-19 18:19:33','2019-08-19 18:19:36','8f004f6b-d5fa-4f32-b5c8-4a61e80f77e2'),
	(9,NULL,'craft\\elements\\Asset',1,0,'2019-08-19 17:58:46','2019-08-19 17:58:46','2019-08-19 18:01:08','293f46c2-b3ee-4eec-8014-436519a100dc'),
	(10,NULL,'craft\\elements\\Asset',1,0,'2019-08-19 18:03:13','2019-08-19 18:03:13','2019-08-19 18:20:52','bcca5913-e6cd-4c9e-a667-5a619438a85b'),
	(11,2,'craft\\elements\\Entry',1,0,'2019-08-19 18:28:43','2019-08-19 19:45:44','2019-08-19 20:14:36','ac97eae4-1743-4361-aafd-d8d38178f3c9'),
	(12,NULL,'craft\\elements\\Asset',1,0,'2019-08-19 18:53:42','2019-08-19 20:22:49',NULL,'040697e4-daf2-47fc-b2b7-da3ca7207b1a'),
	(13,NULL,'craft\\elements\\Asset',1,0,'2019-08-19 19:45:38','2019-08-19 20:22:49',NULL,'d610dc8e-2974-458c-a8d6-f743124c77a8'),
	(14,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:14:36','2019-08-19 20:14:36','2019-08-19 20:14:36','20417f11-588a-441a-9d8c-05c4cc20d28c'),
	(15,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:14:36','2019-08-19 20:14:37','2019-08-19 20:14:58','978a3316-2806-43af-8a1f-061dda497197'),
	(16,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:14:58','2019-08-19 20:14:58','2019-08-19 20:14:58','7f4b6cb7-526a-4fb2-831b-49b354ac8bb0'),
	(17,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:14:58','2019-08-19 20:14:58','2019-08-19 20:14:58','1f7b6b81-8fed-466d-b98c-e09e31b25f1d'),
	(18,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:14:58','2019-08-19 20:16:14','2019-08-19 20:17:06','906d8cd9-47eb-4260-8142-2f8512a9d6a2'),
	(19,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:17:06','2019-08-19 20:19:49','2019-08-19 20:23:28','f360bac3-46a6-463c-b115-dd1692427be9'),
	(20,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:23:28','2019-08-19 20:23:28','2019-08-19 20:23:28','33643ece-7d27-464c-a1b7-d85a8911238b'),
	(21,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:23:28','2019-08-19 20:23:28','2019-08-19 20:23:28','22be235d-863d-43ad-bc3c-8cc1c3e052f9'),
	(22,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:23:28','2019-08-19 20:23:28','2019-08-19 20:25:23','676af732-f5bf-4ca2-a386-10d5d0328cdc'),
	(23,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:25:23','2019-08-19 20:25:23','2019-08-19 20:25:24','3f40c6d1-590f-44c8-9a0c-8a8120c1de3f'),
	(24,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:25:23','2019-08-19 20:25:23','2019-08-19 20:25:37','034c3937-c0f2-4edf-a9e0-f124156246d9'),
	(25,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:25:37','2019-08-19 20:25:37','2019-08-19 20:25:37','351a4ca9-a897-492a-8171-96e70bc277fe'),
	(26,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:25:37','2019-08-19 20:26:00','2019-08-19 20:26:23','34f93e24-13f5-4bf7-9e12-82e57d8ade37'),
	(27,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:26:23','2019-08-19 20:26:23','2019-08-19 20:26:23','7d03ba0a-99d3-4f23-ba78-fc8e16c9cea4'),
	(28,2,'craft\\elements\\Entry',1,0,'2019-08-19 20:26:23','2019-08-19 20:26:54',NULL,'aa23dc47-62a4-4787-ba4f-382b28de645a'),
	(29,5,'craft\\elements\\Entry',1,0,'2020-01-29 19:37:56','2020-01-29 20:03:22',NULL,'1d8b0dad-96ee-4d9c-bff7-441bf263d61b'),
	(30,4,'craft\\elements\\MatrixBlock',1,0,'2020-01-29 19:38:40','2020-01-29 20:03:22',NULL,'107db812-7756-40be-84eb-c97a6cfbe15d'),
	(31,4,'craft\\elements\\MatrixBlock',1,0,'2020-01-29 19:43:14','2020-01-29 19:46:04','2020-01-29 19:59:24','738e909d-5873-409a-b9f9-0d4d5a9c34f0'),
	(32,6,'verbb\\supertable\\elements\\SuperTableBlockElement',1,0,'2020-01-29 19:59:24','2020-01-29 20:03:23',NULL,'6dddd87d-2a0d-4bb1-bb6f-42b727325a7f');
UNLOCK TABLES;


LOCK TABLES `assets` WRITE;
INSERT INTO `assets` (`id`, `volumeId`, `folderId`, `filename`, `kind`, `width`, `height`, `size`, `focalPoint`, `deletedWithVolume`, `keptFile`, `dateModified`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(4,NULL,2,'Screenshot-2019-08-19-09.11.34.png','image',589,594,503480,NULL,0,0,'2019-08-19 16:09:10','2019-08-19 16:09:10','2019-08-19 16:09:10','4fe429e0-bb36-4af5-a0b7-9f6b0fd0da96'),
	(6,1,3,'Screenshot-2019-08-19-09.11.34.png','image',589,594,503480,NULL,0,0,'2019-08-19 17:49:33','2019-08-19 17:49:33','2019-08-19 17:49:33','4e7a1751-f810-4671-bdba-55f582f120c7'),
	(9,1,3,'Screenshot-2019-08-17-11.33.14.png','image',661,741,575875,NULL,0,0,'2019-08-19 17:58:47','2019-08-19 17:58:47','2019-08-19 17:58:47','0029fd6f-0645-443b-9ed4-45d83e1de3ca'),
	(10,1,3,'Screenshot-2019-08-19-09.11.34.png','image',589,594,503480,NULL,1,1,'2019-08-19 18:03:14','2019-08-19 18:03:14','2019-08-19 18:03:14','b758ae38-3ad5-4a93-8350-c5d1a9e0e44b'),
	(12,3,5,'guitar.png','image',589,594,503480,NULL,NULL,NULL,'2019-08-19 18:53:42','2019-08-19 18:53:42','2019-08-19 20:22:49','fcdc79ce-0cab-4a4e-934b-102699455a32'),
	(13,3,5,'stonybrook.png','image',597,596,843438,NULL,NULL,NULL,'2019-08-19 19:45:39','2019-08-19 19:45:39','2019-08-19 20:22:49','3a797f71-ce55-40d9-9a12-4086fca9b9c4');
UNLOCK TABLES;


LOCK TABLES `assettransformindex` WRITE;
INSERT INTO `assettransformindex` (`id`, `assetId`, `filename`, `format`, `location`, `volumeId`, `fileExists`, `inProgress`, `dateIndexed`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,12,'guitar.png',NULL,'_300x200_crop_center-center_none',3,1,0,'2019-08-19 20:22:52','2019-08-19 20:22:52','2019-08-19 20:22:53','ac63377e-a35c-44c4-9c49-267f4ceac313'),
	(2,13,'stonybrook.png',NULL,'_500x500_crop_center-center_100_none',3,1,0,'2019-08-19 20:26:40','2019-08-19 20:26:40','2019-08-19 20:26:41','f1151105-d3d3-47a8-9915-4f3e48ed4278'),
	(3,12,'guitar.png',NULL,'_500x500_crop_center-center_100_none',3,1,0,'2019-08-19 20:26:40','2019-08-19 20:26:40','2019-08-19 20:26:41','859f5813-5e6a-4832-83e5-0f0179bd3309'),
	(4,13,'stonybrook.png',NULL,'_297x231_crop_center-center_none',3,1,0,'2020-01-29 19:59:27','2020-01-29 19:59:27','2020-01-29 19:59:28','d54b1875-b0c9-4e8a-85c0-abce339601f4'),
	(5,13,'stonybrook.png',NULL,'_245x191_crop_center-center_none',3,1,0,'2020-01-29 19:59:27','2020-01-29 19:59:27','2020-01-29 19:59:28','6d529867-72ac-465f-a6f8-57b4312923f6'),
	(6,13,'stonybrook.png',NULL,'_500x500_crop_center-center_none',3,1,0,'2020-01-29 20:00:38','2020-01-29 20:00:38','2020-01-29 20:00:38','92af6dba-6448-4232-9ab1-fc686a16754b'),
	(7,13,'stonybrook.png',NULL,'_800x800_crop_center-center_100_none',3,1,0,'2020-05-19 19:52:10','2020-05-19 19:52:10','2020-05-19 19:52:12','81389e08-83c7-4e0f-8f48-3715d031cfd1'),
	(8,12,'guitar.png',NULL,'_800x800_crop_center-center_100_none',3,1,0,'2020-05-19 19:52:10','2020-05-19 19:52:10','2020-05-19 19:52:12','3c8d90e4-7a37-4673-8228-fe00505d6095'),
	(9,13,'stonybrook.png',NULL,'_1200x800_crop_center-center_100_none',3,1,0,'2020-05-20 20:04:37','2020-05-20 20:04:37','2020-05-20 20:04:40','ef539096-f917-4846-a9b8-52d334e5d1d1'),
	(10,12,'guitar.png',NULL,'_1200x800_crop_center-center_100_none',3,1,0,'2020-05-20 20:04:37','2020-05-20 20:04:37','2020-05-20 20:04:39','24ae258a-41f9-4ab2-9efb-6b187506cce0'),
	(11,13,'stonybrook.png',NULL,'_2000x800_crop_center-center_100_none',3,1,0,'2020-05-20 20:05:28','2020-05-20 20:05:28','2020-05-20 20:05:32','33f2a2c6-a738-46d5-afac-8316880f1eb7'),
	(12,12,'guitar.png',NULL,'_2000x800_crop_center-center_100_none',3,1,0,'2020-05-20 20:05:28','2020-05-20 20:05:28','2020-05-20 20:05:30','a1dd479b-861b-4395-91da-6bb8845229eb'),
	(13,13,'stonybrook.png',NULL,'_1000x1000_crop_center-center_100_none',3,1,0,'2020-05-26 15:27:20','2020-05-26 15:27:20','2020-05-26 15:27:22','41c5fa95-4eee-4a40-b05a-6e995a7e4e01'),
	(14,13,'stonybrook.png',NULL,'_4000x1600_crop_center-center_100_none',3,1,0,'2020-05-26 15:27:20','2020-05-26 15:27:20','2020-05-26 15:27:26','1f65389a-310d-4a8a-9055-91b53f08c828'),
	(15,12,'guitar.png',NULL,'_1000x1000_crop_center-center_100_none',3,1,0,'2020-05-26 15:27:20','2020-05-26 15:27:20','2020-05-26 15:27:27','1f1eae37-0940-45cb-ba0a-668f41ecf558'),
	(16,12,'guitar.png',NULL,'_4000x1600_crop_center-center_100_none',3,1,0,'2020-05-26 15:27:20','2020-05-26 15:27:20','2020-05-26 15:27:32','d5abef03-f48f-4fbb-b944-0d5bef70c810'),
	(17,13,NULL,NULL,'_4000x1600__center-center_100_none',3,0,1,'2020-05-26 15:27:58','2020-05-26 15:27:58','2020-05-26 15:27:59','d1db978c-4acd-4c24-b174-fc20c38c84d8'),
	(18,12,NULL,NULL,'_4000x1600__center-center_100_none',3,0,1,'2020-05-26 15:27:58','2020-05-26 15:27:58','2020-05-26 15:27:59','5e36cf55-c9e6-44c5-9af5-c5643b3bba69');
UNLOCK TABLES;


LOCK TABLES `assettransforms` WRITE;
UNLOCK TABLES;


LOCK TABLES `categorygroups` WRITE;
UNLOCK TABLES;


LOCK TABLES `categories` WRITE;
UNLOCK TABLES;


LOCK TABLES `categorygroups_sites` WRITE;
UNLOCK TABLES;


LOCK TABLES `content` WRITE;
INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_contentEntry`) VALUES 
	(1,1,1,NULL,'2019-05-23 15:26:20','2019-05-23 15:26:20','703e72af-0433-4c28-916c-39f2c1619ff1',NULL),
	(2,2,1,'Home','2019-06-17 17:16:56','2020-01-03 17:09:04','29dcd78c-fff9-4cb9-b7fe-07e6e25ab442',NULL),
	(3,3,1,'Image Transforms','2019-08-19 16:00:26','2019-08-19 16:15:47','96e2558a-8740-40c5-b327-c80338337312',NULL),
	(4,4,1,'Screenshot 2019 08 19 09 11 34','2019-08-19 16:09:10','2019-08-19 16:09:10','7b7e28a8-585c-4223-8ab1-54cb3fc49c5e',NULL),
	(5,5,1,'Image Transforms','2019-08-19 17:37:50','2019-08-19 17:49:41','3ff6c933-282b-41b0-b7f7-d627fcce3c07','<figure><img src="#asset:6" alt="" /></figure><p>This is the entry text</p>'),
	(6,6,1,'Screenshot 2019 08 19 09 11 34','2019-08-19 17:49:32','2019-08-19 17:49:32','61adaa65-edb4-4863-a5b6-86b6cdb8793c',NULL),
	(7,7,1,'Image Transforms','2019-08-19 17:52:29','2019-08-19 17:54:47','41c96da6-0cec-4213-8842-3bfc1297ad6d','<p>some text</p>'),
	(8,8,1,'Image Transforms','2019-08-19 17:56:25','2019-08-19 18:19:33','92cb7116-fc9e-4253-899e-b975810df04e','\n<p>Hello World</p>'),
	(9,9,1,'Screenshot 2019 08 17 11 33 14','2019-08-19 17:58:46','2019-08-19 17:58:46','b0ed78b8-ce7d-45ec-9b13-79ee3c507bb4',NULL),
	(10,10,1,'Screenshot 2019 08 19 09 11 34','2019-08-19 18:03:13','2019-08-19 18:03:13','6ad8216c-0a9c-49e6-9cb9-2bbe006b3a73',NULL),
	(11,11,1,'Image Transforms','2019-08-19 18:28:43','2019-08-19 19:45:44','cc05a792-3ab6-4be8-9457-475cb44fe457','<figure><img src="{asset:12:url}" alt="" /></figure><p>Hello World</p>'),
	(12,12,1,'squier-title','2019-08-19 18:53:42','2019-08-19 20:22:49','a2cddaa6-2c0b-4446-9055-11c792d32579',NULL),
	(13,13,1,'Stonybrook','2019-08-19 19:45:38','2019-08-19 20:22:49','4630e086-be02-474a-bcb4-b297d96e5653',NULL),
	(14,14,1,'Craft','2019-08-19 20:14:36','2019-08-19 20:14:36','7a3d9730-1f5b-46af-8ef5-bed1485dec4c',NULL),
	(15,15,1,'Craft','2019-08-19 20:14:36','2019-08-19 20:14:37','71d36d67-370f-4497-93c4-6da6c24c8a14',NULL),
	(16,16,1,'Image Transforms','2019-08-19 20:14:58','2019-08-19 20:14:58','5b2c05bb-a386-4cec-97f8-8d166d430582',NULL),
	(17,17,1,'Image Transforms','2019-08-19 20:14:58','2019-08-19 20:14:58','63ccfcc7-cb0e-4818-9045-51edc0155d15',NULL),
	(18,18,1,'Image Transforms','2019-08-19 20:14:58','2019-08-19 20:16:14','2ac19055-ba20-4e24-b226-31a490c11998','<figure><img src="{asset:12:url}" alt="" /></figure>'),
	(19,19,1,'Image Transforms','2019-08-19 20:17:06','2019-08-19 20:19:49','91fd3413-9f5a-48b3-b6ba-124bc50bd5e1','<figure><img src="{asset:12:url}" alt="" /></figure>'),
	(20,20,1,'Image Transforms','2019-08-19 20:23:28','2019-08-19 20:23:28','73f5a231-b718-42a3-b403-fff0387c6179',NULL),
	(21,21,1,'Image Transforms','2019-08-19 20:23:28','2019-08-19 20:23:28','a6bd3af0-6b2a-4036-9e9c-c49024937cdf',NULL),
	(22,22,1,'Image Transforms','2019-08-19 20:23:28','2019-08-19 20:23:28','60e65661-5ec1-431a-82d6-5c95edde9b7d',NULL),
	(23,23,1,'Image Transforms','2019-08-19 20:25:23','2019-08-19 20:25:23','af06d199-9156-4424-89ee-46390d965836',NULL),
	(24,24,1,'Image Transforms','2019-08-19 20:25:23','2019-08-19 20:25:23','82e9c3e3-1c6d-41c3-8b40-9eb73daf45ff',NULL),
	(25,25,1,'Image Transforms','2019-08-19 20:25:37','2019-08-19 20:25:37','0e6e3459-5f4e-46fe-b0ab-72b6ca267c3d',NULL),
	(26,26,1,'Image Transforms','2019-08-19 20:25:37','2019-08-19 20:26:00','dc5894d8-e63f-4a9d-9b3a-872384994bea',NULL),
	(27,27,1,'Image Transforms','2019-08-19 20:26:23','2019-08-19 20:26:23','82e8c093-e0bb-4a43-b325-609a3f568584',NULL),
	(28,28,1,'Image Transforms','2019-08-19 20:26:23','2019-08-19 20:26:54','67495949-dfd6-4bf1-87a4-12405f706775','<figure><img src="{asset:12:url}" alt="" /></figure>'),
	(29,29,1,'Controllers','2020-01-29 19:37:56','2020-01-29 20:03:22','f3454a19-19f5-4d13-b1fe-b96bb7339d08',NULL);
UNLOCK TABLES;


LOCK TABLES `craftidtokens` WRITE;
UNLOCK TABLES;


LOCK TABLES `deprecationerrors` WRITE;
INSERT INTO `deprecationerrors` (`id`, `key`, `fingerprint`, `lastOccurrence`, `file`, `line`, `message`, `traces`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,'validation.key','/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/services/Config.php:175','2019-10-21 18:33:50','/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/services/Config.php',175,'The auto-generated validation key stored at /Users/dgaebel/Sites/helpers/src/storage/runtime/validation.key has been deprecated. Copy its value to the “securityKey” config setting in config/general.php.','[{"objectClass":"craft\\\\services\\\\Deprecator","file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/services/Config.php","line":127,"class":"craft\\\\services\\\\Deprecator","method":"log","args":"\\"validation.key\\", \\"The auto-generated validation key stored at /Users/dgaebel/Sites...\\""},{"objectClass":"craft\\\\services\\\\Config","file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/services/Config.php","line":175,"class":"craft\\\\services\\\\Config","method":"getConfigSettings","args":"\\"general\\""},{"objectClass":"craft\\\\services\\\\Config","file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/helpers/App.php","line":614,"class":"craft\\\\services\\\\Config","method":"getGeneral","args":null},{"objectClass":null,"file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/config/app.web.php","line":11,"class":"craft\\\\helpers\\\\App","method":"webRequestConfig","args":null},{"objectClass":null,"file":null,"line":null,"class":null,"method":"{closure}","args":null},{"objectClass":null,"file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/di/Container.php","line":508,"class":null,"method":"call_user_func_array","args":"Closure, []"},{"objectClass":"yii\\\\di\\\\Container","file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/BaseYii.php","line":351,"class":"yii\\\\di\\\\Container","method":"invoke","args":"Closure, []"},{"objectClass":null,"file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/di/ServiceLocator.php","line":137,"class":"yii\\\\BaseYii","method":"createObject","args":"Closure"},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/base/Module.php","line":742,"class":"yii\\\\di\\\\ServiceLocator","method":"get","args":"\\"request\\", true"},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/web/Application.php","line":348,"class":"yii\\\\base\\\\Module","method":"get","args":"\\"request\\", true"},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/web/Application.php","line":160,"class":"craft\\\\web\\\\Application","method":"get","args":"\\"request\\""},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/helpers/App.php","line":487,"class":"yii\\\\web\\\\Application","method":"getRequest","args":null},{"objectClass":null,"file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/config/app.php","line":207,"class":"craft\\\\helpers\\\\App","method":"logConfig","args":null},{"objectClass":null,"file":null,"line":null,"class":null,"method":"{closure}","args":null},{"objectClass":null,"file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/di/Container.php","line":508,"class":null,"method":"call_user_func_array","args":"Closure, []"},{"objectClass":"yii\\\\di\\\\Container","file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/BaseYii.php","line":351,"class":"yii\\\\di\\\\Container","method":"invoke","args":"Closure, []"},{"objectClass":null,"file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/di/ServiceLocator.php","line":137,"class":"yii\\\\BaseYii","method":"createObject","args":"Closure"},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/base/Module.php","line":742,"class":"yii\\\\di\\\\ServiceLocator","method":"get","args":"\\"log\\", true"},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/web/Application.php","line":348,"class":"yii\\\\base\\\\Module","method":"get","args":"\\"log\\", true"},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/base/Application.php","line":508,"class":"craft\\\\web\\\\Application","method":"get","args":"\\"log\\""},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/base/ApplicationTrait.php","line":1221,"class":"yii\\\\base\\\\Application","method":"getLog","args":null},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/web/Application.php","line":109,"class":"craft\\\\web\\\\Application","method":"_preInit","args":null},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/base/BaseObject.php","line":109,"class":"craft\\\\web\\\\Application","method":"init","args":null},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/base/Application.php","line":206,"class":"yii\\\\base\\\\BaseObject","method":"__construct","args":"[\\"env\\" => \\"local\\", \\"components\\" => [\\"config\\" => craft\\\\services\\\\Config, \\"api\\" => [\\"class\\" => \\"craft\\\\services\\\\Api\\"], \\"assets\\" => [\\"class\\" => \\"craft\\\\services\\\\Assets\\"], \\"assetIndexer\\" => [\\"class\\" => \\"craft\\\\services\\\\AssetIndexer\\"], ...], \\"id\\" => \\"CraftCMS\\", \\"name\\" => \\"Craft CMS\\", ...]"},{"objectClass":"craft\\\\web\\\\Application","file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/src/web/Application.php","line":100,"class":"yii\\\\base\\\\Application","method":"__construct","args":"[\\"env\\" => \\"local\\", \\"components\\" => [\\"config\\" => craft\\\\services\\\\Config, \\"api\\" => [\\"class\\" => \\"craft\\\\services\\\\Api\\"], \\"assets\\" => [\\"class\\" => \\"craft\\\\services\\\\Assets\\"], \\"assetIndexer\\" => [\\"class\\" => \\"craft\\\\services\\\\AssetIndexer\\"], ...], \\"id\\" => \\"CraftCMS\\", \\"name\\" => \\"Craft CMS\\", ...]"},{"objectClass":"craft\\\\web\\\\Application","file":null,"line":null,"class":"craft\\\\web\\\\Application","method":"__construct","args":"[\\"vendorPath\\" => \\"/Users/dgaebel/Sites/helpers/src/vendor\\", \\"env\\" => \\"local\\", \\"components\\" => [\\"config\\" => craft\\\\services\\\\Config, \\"api\\" => [\\"class\\" => \\"craft\\\\services\\\\Api\\"], \\"assets\\" => [\\"class\\" => \\"craft\\\\services\\\\Assets\\"], \\"assetIndexer\\" => [\\"class\\" => \\"craft\\\\services\\\\AssetIndexer\\"], ...], \\"id\\" => \\"CraftCMS\\", ...]"},{"objectClass":"ReflectionClass","file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/di/Container.php","line":384,"class":"ReflectionClass","method":"newInstanceArgs","args":"[[\\"vendorPath\\" => \\"/Users/dgaebel/Sites/helpers/src/vendor\\", \\"env\\" => \\"local\\", \\"components\\" => [\\"config\\" => craft\\\\services\\\\Config, \\"api\\" => [\\"class\\" => \\"craft\\\\services\\\\Api\\"], \\"assets\\" => [\\"class\\" => \\"craft\\\\services\\\\Assets\\"], \\"assetIndexer\\" => [\\"class\\" => \\"craft\\\\services\\\\AssetIndexer\\"], ...], \\"id\\" => \\"CraftCMS\\", ...]]"},{"objectClass":"yii\\\\di\\\\Container","file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/di/Container.php","line":156,"class":"yii\\\\di\\\\Container","method":"build","args":"\\"craft\\\\web\\\\Application\\", [], [\\"vendorPath\\" => \\"/Users/dgaebel/Sites/helpers/src/vendor\\", \\"env\\" => \\"local\\", \\"components\\" => [\\"config\\" => craft\\\\services\\\\Config, \\"api\\" => [\\"class\\" => \\"craft\\\\services\\\\Api\\"], \\"assets\\" => [\\"class\\" => \\"craft\\\\services\\\\Assets\\"], \\"assetIndexer\\" => [\\"class\\" => \\"craft\\\\services\\\\AssetIndexer\\"], ...], \\"id\\" => \\"CraftCMS\\", ...]"},{"objectClass":"yii\\\\di\\\\Container","file":"/Users/dgaebel/Sites/helpers/src/vendor/yiisoft/yii2/BaseYii.php","line":349,"class":"yii\\\\di\\\\Container","method":"get","args":"\\"craft\\\\web\\\\Application\\", [], [\\"vendorPath\\" => \\"/Users/dgaebel/Sites/helpers/src/vendor\\", \\"env\\" => \\"local\\", \\"components\\" => [\\"config\\" => craft\\\\services\\\\Config, \\"api\\" => [\\"class\\" => \\"craft\\\\services\\\\Api\\"], \\"assets\\" => [\\"class\\" => \\"craft\\\\services\\\\Assets\\"], \\"assetIndexer\\" => [\\"class\\" => \\"craft\\\\services\\\\AssetIndexer\\"], ...], \\"id\\" => \\"CraftCMS\\", ...]"},{"objectClass":null,"file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/bootstrap/bootstrap.php","line":248,"class":"yii\\\\BaseYii","method":"createObject","args":"[\\"vendorPath\\" => \\"/Users/dgaebel/Sites/helpers/src/vendor\\", \\"env\\" => \\"local\\", \\"components\\" => [\\"config\\" => craft\\\\services\\\\Config, \\"api\\" => [\\"class\\" => \\"craft\\\\services\\\\Api\\"], \\"assets\\" => [\\"class\\" => \\"craft\\\\services\\\\Assets\\"], \\"assetIndexer\\" => [\\"class\\" => \\"craft\\\\services\\\\AssetIndexer\\"], ...], \\"id\\" => \\"CraftCMS\\", ...]"},{"objectClass":null,"file":"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/bootstrap/web.php","line":52,"class":null,"method":"require","args":"\\"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/bootstrap/b...\\""},{"objectClass":null,"file":"/Users/dgaebel/Sites/helpers/src/public/index.php","line":20,"class":null,"method":"require","args":"\\"/Users/dgaebel/Sites/helpers/src/vendor/craftcms/cms/bootstrap/w...\\""}]','2019-10-21 18:33:50','2019-10-21 18:33:50','478989f2-5976-4b58-b1e7-86367a219b39');
UNLOCK TABLES;


LOCK TABLES `elementindexsettings` WRITE;
UNLOCK TABLES;


LOCK TABLES `elements_sites` WRITE;
INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,1,1,NULL,NULL,1,'2019-05-23 15:26:20','2019-05-23 15:26:20','68644a09-f0b8-46d6-ab27-befe51ffd97e'),
	(2,2,1,'home','__home__',1,'2019-06-17 17:16:56','2020-01-03 17:09:04','34a88d98-b4da-449b-847b-17bc57816e10'),
	(3,3,1,'image-transforms','craft/image-transforms',1,'2019-08-19 16:00:26','2019-08-19 16:15:47','51d14a3d-fe5c-47c4-a5bc-041f35016402'),
	(4,4,1,NULL,NULL,1,'2019-08-19 16:09:10','2019-08-19 16:09:10','67de56dc-195e-4312-a57f-d5153b81bb02'),
	(5,5,1,'image-transforms','craft/image-transforms',1,'2019-08-19 17:37:50','2019-08-19 17:49:41','e1117e1e-ff27-4513-b6fc-c9815b07b6d0'),
	(6,6,1,NULL,NULL,1,'2019-08-19 17:49:32','2019-08-19 17:49:32','5f9ace5b-9308-482e-9d79-65c691c528e6'),
	(7,7,1,'image-transforms','craft/image-transforms',1,'2019-08-19 17:52:29','2019-08-19 17:54:47','4e8ac104-27c7-4ac4-96eb-5f04872448e8'),
	(8,8,1,'image-transforms','craft/image-transforms',1,'2019-08-19 17:56:25','2019-08-19 18:19:33','c9c77cff-6a14-41d2-beea-17058b054980'),
	(9,9,1,NULL,NULL,1,'2019-08-19 17:58:46','2019-08-19 17:58:46','0566e7c1-f553-4049-9feb-710b34439db8'),
	(10,10,1,NULL,NULL,1,'2019-08-19 18:03:13','2019-08-19 18:03:13','9f0f0369-9f3d-4baa-8eb2-ecfc06af586f'),
	(11,11,1,'image-transforms','craft/image-transforms',1,'2019-08-19 18:28:43','2019-08-19 19:45:44','95240d59-01cd-4302-88df-d5204d51f9be'),
	(12,12,1,NULL,NULL,1,'2019-08-19 18:53:42','2019-08-19 20:22:49','7b843cb6-c3bf-4f15-85da-37358f312abd'),
	(13,13,1,NULL,NULL,1,'2019-08-19 19:45:38','2019-08-19 20:22:49','7ecc6f79-a8a0-43ce-bb52-63f1c63703b7'),
	(14,14,1,'craft','craft',1,'2019-08-19 20:14:36','2019-08-19 20:14:36','45b9696d-d1e0-4426-addb-6a14e385a70e'),
	(15,15,1,'craft-1','craft-1',1,'2019-08-19 20:14:36','2019-08-19 20:14:37','a6a4cca8-04de-4e4b-83b3-81ebaadb1818'),
	(16,16,1,'image-transforms','image-transforms',1,'2019-08-19 20:14:58','2019-08-19 20:14:58','c79065f5-a4eb-409d-8789-65cdce8cbbea'),
	(17,17,1,'image-transforms-1','image-transforms-1',1,'2019-08-19 20:14:58','2019-08-19 20:14:58','7d6a600b-2a97-4640-8753-d5abfd59e5a8'),
	(18,18,1,'image-transforms','image-transforms',1,'2019-08-19 20:14:58','2019-08-19 20:16:14','810a5fed-ddd6-4a6f-a218-2449f52b486a'),
	(19,19,1,'image-transforms-1','image-transforms-1',1,'2019-08-19 20:17:06','2019-08-19 20:19:49','cf1633ee-1d38-4ed0-b512-a5244e40b738'),
	(20,20,1,'image-transforms','image-transforms',1,'2019-08-19 20:23:28','2019-08-19 20:23:28','0ca34943-2d83-4976-aa50-e3eeaf9b9058'),
	(21,21,1,'image-transforms-1','image-transforms-1',1,'2019-08-19 20:23:28','2019-08-19 20:23:28','2cfeef00-780c-4c76-aac8-aa3c6801ac79'),
	(22,22,1,'image-transforms','image-transforms',1,'2019-08-19 20:23:28','2019-08-19 20:23:28','6cad95fe-280b-4d6a-96e5-3acf29541aae'),
	(23,23,1,'image-transforms-1','image-transforms-1',1,'2019-08-19 20:25:23','2019-08-19 20:25:23','75112007-1365-448b-b775-0cf93070e319'),
	(24,24,1,'image-transforms','image-transforms',1,'2019-08-19 20:25:23','2019-08-19 20:25:23','301f8904-7ef1-46b8-a4ce-d64bda6e6807'),
	(25,25,1,'image-transforms-1','image-transforms-1',1,'2019-08-19 20:25:37','2019-08-19 20:25:37','ca4f3fdc-e29f-4877-afe2-27d5da79d156'),
	(26,26,1,'image-transforms','image-transforms',1,'2019-08-19 20:25:37','2019-08-19 20:26:00','6e3706e3-4e57-4968-aed0-4b3d1f95ab64'),
	(27,27,1,'image-transforms-1','image-transforms-1',1,'2019-08-19 20:26:23','2019-08-19 20:26:23','0fdc59da-7283-48af-be9e-4404b019365b'),
	(28,28,1,'image-transforms','image-transforms',1,'2019-08-19 20:26:23','2019-08-19 20:26:54','c5c0e4d5-8fc3-4736-b30a-1b2fb03f01d6'),
	(29,29,1,'controllers','controllers',1,'2020-01-29 19:37:56','2020-01-29 20:03:22','394d2371-3660-4b6d-b3d1-66cba885218b'),
	(30,30,1,NULL,NULL,1,'2020-01-29 19:38:40','2020-01-29 20:03:22','855e0ae6-4cc1-4b7e-b2c0-7c1493f35367'),
	(31,31,1,NULL,NULL,1,'2020-01-29 19:43:14','2020-01-29 19:46:04','d75a0c1d-eef8-4cc9-8b5a-464141a1c5f2'),
	(32,32,1,NULL,NULL,1,'2020-01-29 19:59:24','2020-01-29 20:03:23','10f56c9a-c7c9-4e27-b10e-207af154d535');
UNLOCK TABLES;


LOCK TABLES `entries` WRITE;
INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(2,1,NULL,1,NULL,'2019-06-17 17:16:00',NULL,NULL,'2019-06-17 17:16:56','2020-01-03 17:09:04','a9a5e199-f2a1-4faa-8676-45cb9a807f87'),
	(3,2,NULL,2,1,'2019-08-19 16:00:00',NULL,0,'2019-08-19 16:00:26','2019-08-19 16:15:47','82124594-9268-4f2d-ae8d-3501719ffcfe'),
	(5,2,NULL,2,1,'2019-08-19 17:37:00',NULL,0,'2019-08-19 17:37:50','2019-08-19 17:49:41','ab73686c-d360-4535-8dcb-c847a715dfbc'),
	(7,2,NULL,2,1,'2019-08-19 17:52:00',NULL,0,'2019-08-19 17:52:29','2019-08-19 17:54:47','41f7c096-91ca-4a74-a39b-f6b3eb827708'),
	(8,2,NULL,2,1,'2019-08-19 17:56:00',NULL,0,'2019-08-19 17:56:25','2019-08-19 18:19:33','f35d3bde-d153-4af9-8143-adac080e5d7e'),
	(11,2,NULL,2,1,'2019-08-19 18:28:00',NULL,0,'2019-08-19 18:28:43','2019-08-19 19:45:44','6a33e5fb-7302-4c33-8b0a-4b1958e42bc3'),
	(14,2,NULL,2,NULL,'2019-08-19 20:14:00',NULL,0,'2019-08-19 20:14:36','2019-08-19 20:14:36','cdad1658-da2d-4e1b-bcca-b1b32154b052'),
	(15,2,NULL,2,NULL,'2019-08-19 20:14:00',NULL,0,'2019-08-19 20:14:36','2019-08-19 20:14:37','95bf9c6e-c65d-43c6-a837-14743a386434'),
	(16,2,NULL,2,NULL,'2019-08-19 20:14:00',NULL,0,'2019-08-19 20:14:58','2019-08-19 20:14:58','4bb38b70-a280-4ca1-b6af-f8af6598b45a'),
	(17,2,NULL,2,NULL,'2019-08-19 20:14:00',NULL,0,'2019-08-19 20:14:58','2019-08-19 20:14:58','19109c3a-7e9a-4483-8d16-fe8e046163f5'),
	(18,2,NULL,2,NULL,'2019-08-19 20:14:00',NULL,0,'2019-08-19 20:14:58','2019-08-19 20:16:14','ac78d71a-0fa2-44f7-970a-5e61b5224027'),
	(19,2,NULL,2,NULL,'2019-08-19 20:17:00',NULL,0,'2019-08-19 20:17:06','2019-08-19 20:19:49','be39d753-4905-4a74-8d72-13c7e001a66d'),
	(20,2,NULL,2,NULL,'2019-08-19 20:23:00',NULL,0,'2019-08-19 20:23:28','2019-08-19 20:23:28','6c55c576-2f64-4e4a-89e0-3921880894ad'),
	(21,2,NULL,2,NULL,'2019-08-19 20:23:00',NULL,0,'2019-08-19 20:23:28','2019-08-19 20:23:28','12708e36-25e8-4af1-a3f8-8d744263e909'),
	(22,2,NULL,2,NULL,'2019-08-19 20:23:00',NULL,0,'2019-08-19 20:23:28','2019-08-19 20:23:28','791216f0-1298-4352-9195-852953a52c9e'),
	(23,2,NULL,2,NULL,'2019-08-19 20:25:00',NULL,0,'2019-08-19 20:25:23','2019-08-19 20:25:23','1faf96a7-b439-42cd-b053-41429ab10fa1'),
	(24,2,NULL,2,NULL,'2019-08-19 20:25:00',NULL,0,'2019-08-19 20:25:23','2019-08-19 20:25:23','913ac24e-cfcb-46cf-af03-876a3b6fcc4b'),
	(25,2,NULL,2,NULL,'2019-08-19 20:25:00',NULL,0,'2019-08-19 20:25:37','2019-08-19 20:25:37','20b38e65-07d5-4406-8a1a-f20bc2ba963b'),
	(26,2,NULL,2,NULL,'2019-08-19 20:25:00',NULL,0,'2019-08-19 20:25:37','2019-08-19 20:26:00','c48a1851-ba02-4fb3-9360-4b20ea496911'),
	(27,2,NULL,2,NULL,'2019-08-19 20:26:00',NULL,0,'2019-08-19 20:26:23','2019-08-19 20:26:23','9341cce0-ed6f-489e-8afd-58585a45274b'),
	(28,2,NULL,2,NULL,'2019-08-19 20:26:00',NULL,NULL,'2019-08-19 20:26:23','2019-08-19 20:26:54','218e09bf-114e-4af8-b7c9-8afcc6dc6249'),
	(29,3,NULL,3,NULL,'2020-01-29 19:37:00',NULL,NULL,'2020-01-29 19:37:56','2020-01-29 20:03:22','073db166-6aa8-430b-a00a-c8bc88ff909e');
UNLOCK TABLES;


LOCK TABLES `entrydrafts` WRITE;
UNLOCK TABLES;


LOCK TABLES `fieldlayouts` WRITE;
INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES 
	(1,'craft\\elements\\Entry','2019-06-17 17:19:25','2019-06-17 17:19:25',NULL,'b756f14d-60fb-427a-b4b5-58fe0b055fcb'),
	(2,'craft\\elements\\Entry','2019-08-19 16:00:05','2019-08-19 20:25:37',NULL,'4c88a662-12c5-47e1-ad01-e2f78eb49a77'),
	(3,'craft\\elements\\Asset','2019-08-19 18:10:52','2019-08-19 18:16:00','2019-08-19 18:20:52','7c453476-0cfa-4cb0-9418-20edd0b306fa'),
	(4,'craft\\elements\\MatrixBlock','2020-01-29 19:36:31','2020-01-29 19:58:59',NULL,'074a45da-7356-48b8-8b09-d88f9016cb1b'),
	(5,'craft\\elements\\Entry','2020-01-29 19:38:22','2020-01-29 19:38:22',NULL,'dbbb003e-3bc2-4d77-9b49-6ed463a62267'),
	(6,'verbb\\supertable\\elements\\SuperTableBlockElement','2020-01-29 19:58:59','2020-01-29 19:58:59',NULL,'cf0fe66e-180e-4664-8d9d-9f176ae37dac');
UNLOCK TABLES;


LOCK TABLES `entrytypes` WRITE;
INSERT INTO `entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleLabel`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES 
	(1,1,1,'Home','home',0,'','{section.name|raw}',1,'2019-06-17 17:16:56','2019-06-17 17:19:25',NULL,'391c90b0-7dbf-4919-a1a7-7bee13fc18a8'),
	(2,2,2,'Image Transforms','imageTransforms',1,'Title','',1,'2019-08-19 15:57:39','2019-08-19 20:25:37',NULL,'859f27d2-5570-4602-b0f9-8bb42c39ffa1'),
	(3,3,5,'Controllers','controllers',0,'','{section.name|raw}',1,'2020-01-29 19:37:56','2020-01-29 19:38:22',NULL,'04924666-665d-466d-8dc8-ba0d330c4fd2');
UNLOCK TABLES;


LOCK TABLES `entryversions` WRITE;
INSERT INTO `entryversions` (`id`, `entryId`, `sectionId`, `creatorId`, `siteId`, `num`, `notes`, `data`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,2,1,1,1,1,NULL,'{"typeId":"1","authorId":null,"title":"Home","slug":"home","postDate":1560791760,"expiryDate":null,"enabled":true,"newParentId":null,"fields":[]}','2019-06-17 17:16:56','2019-06-17 17:16:56','2e8a7ac3-5abf-4f1d-976e-76cfeeac63bf'),
	(2,2,1,1,1,2,NULL,'{"typeId":"1","authorId":null,"title":"Home","slug":"home","postDate":1560791760,"expiryDate":null,"enabled":"1","newParentId":null,"fields":[]}','2019-06-17 17:16:56','2019-06-17 17:16:56','4837d651-591e-40cc-913b-e32e447aeda0'),
	(3,2,1,1,1,3,'','{"typeId":"1","authorId":null,"title":"Home","slug":"home","postDate":1560791760,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"1":[]}}','2019-06-17 17:19:43','2019-06-17 17:19:43','29020326-a9f0-4d0f-aa3a-3f4ded189427'),
	(4,3,2,1,1,1,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566230400,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"1":[],"2":"<p>This is some text from the redactor editor</p>"}}','2019-08-19 16:00:26','2019-08-19 16:00:26','b40d4218-95a4-4108-b658-9c2ec7aaeb91'),
	(5,3,2,1,1,2,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566230400,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"1":[],"2":"<figure><img src=\\"#asset:4\\" alt=\\"\\" /></figure><p>This is some text from the redactor editor</p>"}}','2019-08-19 16:09:44','2019-08-19 16:09:44','1893cc9c-c1c8-4b83-9ea5-1bc95315003e'),
	(6,3,2,1,1,3,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566230400,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"1":[],"2":"<figure><img src=\\"{asset:4:url}\\" alt=\\"\\" /></figure><p>This is some text from the redactor editor</p>"}}','2019-08-19 16:10:27','2019-08-19 16:10:27','d248194d-a047-4eaa-9a81-233331e49a0b'),
	(7,3,2,1,1,4,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566230400,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"1":[],"2":null}}','2019-08-19 16:13:03','2019-08-19 16:13:03','8fc5b300-1719-4b28-a14c-674918af13b2'),
	(8,3,2,1,1,5,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566230400,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"1":[],"2":"<p>This is some tetxt</p>"}}','2019-08-19 16:15:47','2019-08-19 16:15:47','96126afa-bb55-4ae0-8193-c209e5dba3f5'),
	(9,5,2,1,1,1,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566236220,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<p>This is the entry text</p>"}}','2019-08-19 17:37:51','2019-08-19 17:37:51','72f046b6-77d4-4a82-a7e3-ebe6f8884c80'),
	(10,5,2,1,1,2,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566236220,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"#asset:6\\" alt=\\"\\" /></figure><p>This is the entry text</p>"}}','2019-08-19 17:49:41','2019-08-19 17:49:41','1a20e759-6d16-4dc6-a336-21995ec3807a'),
	(11,7,2,1,1,1,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237120,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:6:url}\\" alt=\\"\\" /></figure>"}}','2019-08-19 17:52:29','2019-08-19 17:52:29','0972e8f4-ebee-401a-975b-19a2a828a228'),
	(12,7,2,1,1,2,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237120,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"#asset:6:url\\" alt=\\"\\" /></figure><p>some text</p>"}}','2019-08-19 17:52:58','2019-08-19 17:52:58','d1282b90-a5a8-4277-a10f-8f44b1912bb8'),
	(13,7,2,1,1,3,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237120,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"\\n<p>some text</p>"}}','2019-08-19 17:53:14','2019-08-19 17:53:14','f5d456d3-3a05-44ad-a959-18cccd9fc4da'),
	(14,7,2,1,1,4,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237120,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<p>some text</p>"}}','2019-08-19 17:53:43','2019-08-19 17:53:43','b0517690-861c-4f6f-a32d-c5006ef9d9c7'),
	(15,8,2,1,1,1,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<p>Hello World</p>"}}','2019-08-19 17:56:25','2019-08-19 17:56:25','c9bced6e-f244-4c22-9d1c-91aa4b94c582'),
	(16,8,2,1,1,2,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:9:url}\\" alt=\\"\\" /></figure><p>Hello World</p>"}}','2019-08-19 17:59:00','2019-08-19 17:59:00','ce758b2b-6354-4786-b641-1cbd822c8040'),
	(17,8,2,1,1,3,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<p>Hello World</p>"}}','2019-08-19 18:00:56','2019-08-19 18:00:56','efc6d8c7-0b55-4915-83af-248d6e59098e'),
	(18,8,2,1,1,4,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:10:url}\\" alt=\\"\\" /></figure>\\n<p>Hello World</p>"}}','2019-08-19 18:03:25','2019-08-19 18:03:25','14ad09b5-9bb6-4b0f-9cd2-a62c54a52d22'),
	(19,8,2,1,1,5,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:10:url}\\" alt=\\"\\" /></figure><p>Hello World</p>"}}','2019-08-19 18:04:13','2019-08-19 18:04:13','59ef6b17-4b2b-42b0-a61b-4f4952d2014d'),
	(20,8,2,1,1,6,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:10:url}\\" alt=\\"\\" /></figure><p>Hello World</p>","4":["10"]}}','2019-08-19 18:11:31','2019-08-19 18:11:31','d1024e9c-62b8-4299-b341-ded11195601d'),
	(21,8,2,1,1,7,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:10:url}\\" alt=\\"\\" /></figure><p>Hello World</p>","4":[]}}','2019-08-19 18:14:45','2019-08-19 18:14:45','530086f9-5ad7-4398-ad3e-fa8e5495aa3b'),
	(22,8,2,1,1,8,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"\\n<figure><img src=\\"{asset:10:url}\\" alt=\\"\\" /></figure><p>Hello World</p>","4":[]}}','2019-08-19 18:17:17','2019-08-19 18:17:17','dd02fa6e-337c-4038-ac8e-8016c8418402'),
	(23,8,2,1,1,9,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"\\n<p>Hello World</p>","4":[]}}','2019-08-19 18:18:44','2019-08-19 18:18:44','c079f063-2f66-4ab3-8883-35d655d199e8'),
	(24,8,2,1,1,10,NULL,'{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566237360,"expiryDate":null,"enabled":false,"newParentId":null,"fields":{"3":"\\n<p>Hello World</p>","4":[]}}','2019-08-19 18:19:33','2019-08-19 18:19:33','9d3e9775-790f-4725-9320-97efd92e81bf'),
	(25,11,2,1,1,1,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566239280,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<p>Hello World</p>"}}','2019-08-19 18:28:43','2019-08-19 18:28:43','059f590a-fa8a-45f1-af2d-a56efdf8926c'),
	(26,11,2,1,1,2,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566239280,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<p>Hello World</p><figure><img src=\\"#asset:12\\" alt=\\"\\" /></figure>"}}','2019-08-19 18:53:51','2019-08-19 18:53:51','96b39ad3-46ee-42fd-96e2-5a872b3d67f0'),
	(27,11,2,1,1,3,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566239280,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<p>Hello World</p>"}}','2019-08-19 18:55:19','2019-08-19 18:55:19','c16021e1-5803-48c8-ab05-d4e87ba6dded'),
	(28,11,2,1,1,4,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566239280,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:12:url}\\" alt=\\"\\" /></figure><p>Hello World</p>"}}','2019-08-19 18:56:53','2019-08-19 18:56:53','d0200276-082c-4e85-b940-55c19da365d2'),
	(29,11,2,1,1,5,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566239280,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<p>Hello World</p>"}}','2019-08-19 18:57:10','2019-08-19 18:57:10','3833fa4d-979d-4b9e-9592-9831e167712f'),
	(30,11,2,1,1,6,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566239280,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:12:url}\\" alt=\\"\\" /></figure><p>Hello World</p>"}}','2019-08-19 19:05:03','2019-08-19 19:05:03','9f4767a7-51fc-4e1f-98ef-722850e7f56b'),
	(31,11,2,1,1,7,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566239280,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:12:url}\\" alt=\\"\\" /></figure><p>Hello World</p>","5":["12"]}}','2019-08-19 19:43:43','2019-08-19 19:43:43','304146b7-ef6c-430c-8d14-636525bf163f'),
	(32,11,2,1,1,8,'','{"typeId":"2","authorId":"1","title":"Image Transforms","slug":"image-transforms","postDate":1566239280,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:12:url}\\" alt=\\"\\" /></figure><p>Hello World</p>","5":["12","13"]}}','2019-08-19 19:45:44','2019-08-19 19:45:44','72efe74a-335f-4894-b7b5-a96efca21174'),
	(33,14,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Craft","slug":"craft","postDate":1566245640,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:14:36','2019-08-19 20:14:36','7c500a13-7529-4152-985a-19af52a1dc8c'),
	(34,15,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Craft","slug":"craft-1","postDate":1566245640,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:14:36','2019-08-19 20:14:36','26c42338-39ea-4bca-a68f-e8afea7cef2a'),
	(35,16,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566245640,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:14:58','2019-08-19 20:14:58','ef17c0dc-b632-4d78-8f3d-2c28acc8865c'),
	(36,17,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms-1","postDate":1566245640,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:14:58','2019-08-19 20:14:58','e73b08e4-6b7d-46e8-a9df-5c78bf962b7e'),
	(37,18,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566245640,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:14:58','2019-08-19 20:14:58','ee5d5b21-0292-4149-a009-cc132c564fa6'),
	(38,18,2,1,1,2,'','{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566245640,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:12:url}\\" alt=\\"\\" /></figure>","5":[]}}','2019-08-19 20:16:14','2019-08-19 20:16:14','62318f7a-dd35-4658-a8fa-a7228e94c5f0'),
	(39,19,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms-1","postDate":1566245820,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:17:06','2019-08-19 20:17:06','11bf35f4-30ec-4cc2-9311-01b7ba426c74'),
	(40,19,2,1,1,2,'','{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms-1","postDate":1566245820,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:12:url}\\" alt=\\"\\" /></figure>","5":[]}}','2019-08-19 20:17:25','2019-08-19 20:17:25','b20ac84d-5a18-4cac-b052-ce4555c8fe4c'),
	(41,19,2,1,1,3,'','{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms-1","postDate":1566245820,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:12:url}\\" alt=\\"\\" /></figure>","5":["13","12"]}}','2019-08-19 20:17:36','2019-08-19 20:17:36','63cf5d9c-86fb-401e-aa10-39a1a836cf48'),
	(42,20,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566246180,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:23:28','2019-08-19 20:23:28','b966f4f6-d6b0-45dc-bcf9-ac161a8a3443'),
	(43,21,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms-1","postDate":1566246180,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:23:28','2019-08-19 20:23:28','8aff729d-3bc2-47cf-a505-d6de47e79434'),
	(44,22,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566246180,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:23:28','2019-08-19 20:23:28','b7ed2356-c8dd-44a7-82b0-97b128de63cf'),
	(45,23,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms-1","postDate":1566246300,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:25:23','2019-08-19 20:25:23','2cbe2c91-5151-4fe5-9bfd-f68a33914fe9'),
	(46,24,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566246300,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:25:23','2019-08-19 20:25:23','075601b8-f6fa-4d38-be3b-1bd402967c10'),
	(47,25,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms-1","postDate":1566246300,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null}}','2019-08-19 20:25:37','2019-08-19 20:25:37','a1e7b769-9fe9-4e51-8674-d5324e578936'),
	(48,26,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566246300,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null}}','2019-08-19 20:25:37','2019-08-19 20:25:37','a9028280-fd59-4a4b-8db4-ce553b28051f'),
	(49,26,2,1,1,2,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566246300,"expiryDate":null,"enabled":false,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:25:53','2019-08-19 20:25:53','0810c0c1-d0b4-4995-80d0-40da7302f238'),
	(50,26,2,1,1,3,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566246300,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:26:00','2019-08-19 20:26:00','86275d89-4dd2-42e3-9ec9-6e38367c3683'),
	(51,27,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms-1","postDate":1566246360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:26:23','2019-08-19 20:26:23','ca2c0a03-40bc-4982-9e7b-8060e34d03c2'),
	(52,28,2,1,1,1,NULL,'{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566246360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":[]}}','2019-08-19 20:26:23','2019-08-19 20:26:23','298f8b6d-abd7-4f19-9efb-8a0d5fc94559'),
	(53,28,2,1,1,2,'','{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566246360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":null,"5":["13","12"]}}','2019-08-19 20:26:37','2019-08-19 20:26:37','79e90bef-d639-4084-91e6-73037aaa31f4'),
	(54,28,2,1,1,3,'','{"typeId":"2","authorId":null,"title":"Image Transforms","slug":"image-transforms","postDate":1566246360,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"3":"<figure><img src=\\"{asset:12:url}\\" alt=\\"\\" /></figure>","5":["13","12"]}}','2019-08-19 20:26:54','2019-08-19 20:26:54','7d21b1f5-c817-41bd-a37a-fbca3ef3d95c'),
	(55,2,1,1,1,4,NULL,'{"typeId":"1","authorId":null,"title":"Home","slug":"home","postDate":1560791760,"expiryDate":null,"enabled":"1","newParentId":null,"fields":{"1":[]}}','2020-01-03 17:09:03','2020-01-03 17:09:03','cb224228-a8e6-413d-98b2-48255f93a572'),
	(56,29,3,1,1,1,NULL,'{"typeId":"3","authorId":null,"title":"Controllers","slug":"controllers","postDate":1580326620,"expiryDate":null,"enabled":true,"newParentId":null,"fields":[]}','2020-01-29 19:37:56','2020-01-29 19:37:56','8a540a59-1711-4f80-9e6d-e89b8b5f5a78'),
	(57,29,3,1,1,2,NULL,'{"typeId":"3","authorId":null,"title":"Controllers","slug":"controllers","postDate":1580326620,"expiryDate":null,"enabled":"1","newParentId":null,"fields":[]}','2020-01-29 19:37:56','2020-01-29 19:37:56','65c26633-5a62-42f6-b9b5-18ca2e164c8e'),
	(58,29,3,1,1,3,'','{"typeId":"3","authorId":null,"title":"Controllers","slug":"controllers","postDate":1580326620,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"1":[],"6":{"30":{"type":"imagesRow","enabled":true,"collapsed":false,"fields":{"heading":"This is a heading from images row module"}}}}}','2020-01-29 19:38:40','2020-01-29 19:38:40','683dff49-e8d0-495b-9b79-2b0e20fedf21'),
	(59,29,3,1,1,4,NULL,'{"typeId":"3","authorId":null,"title":"Controllers","slug":"controllers","postDate":1580326620,"expiryDate":null,"enabled":"1","newParentId":null,"fields":{"1":[],"6":{"30":{"type":"imagesRow","enabled":"1","collapsed":false,"fields":{"heading":"This is a heading from images row module"}}}}}','2020-01-29 19:39:42','2020-01-29 19:39:42','88378652-45ab-428e-b5e6-af4048714cc7'),
	(60,29,3,1,1,5,'','{"typeId":"3","authorId":null,"title":"Controllers","slug":"controllers","postDate":1580326620,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"1":[],"6":{"30":{"type":"imagesRow","enabled":true,"collapsed":false,"fields":{"heading":"This is a heading from images row module"}}}}}','2020-01-29 19:39:54','2020-01-29 19:39:54','fec84414-12c6-4a83-896a-6eba86e1d868'),
	(61,29,3,1,1,6,'','{"typeId":"3","authorId":null,"title":"Controllers","slug":"controllers","postDate":1580326620,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"1":[],"6":{"30":{"type":"imagesRow","enabled":true,"collapsed":false,"fields":{"heading":"This is a heading from images row module"}},"31":{"type":"imagesRow","enabled":true,"collapsed":false,"fields":{"heading":"This is another heading"}}}}}','2020-01-29 19:43:14','2020-01-29 19:43:14','36a3b648-731b-48fe-955c-cc34598a1e72'),
	(62,29,3,1,1,7,NULL,'{"typeId":"3","authorId":null,"title":"Controllers","slug":"controllers","postDate":1580326620,"expiryDate":null,"enabled":"1","newParentId":null,"fields":{"1":[],"6":{"30":{"type":"imagesRow","enabled":"1","collapsed":false,"fields":{"heading":"This is a heading from images row module"}},"31":{"type":"imagesRow","enabled":"1","collapsed":false,"fields":{"heading":"This is another heading"}}}}}','2020-01-29 19:43:48','2020-01-29 19:43:48','21901225-404f-47c5-bde9-1a6df27fd8b3'),
	(63,29,3,1,1,8,'','{"typeId":"3","authorId":null,"title":"Controllers","slug":"controllers","postDate":1580326620,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"1":[],"6":{"30":{"type":"imagesRow","enabled":true,"collapsed":false,"fields":{"heading":"This is a heading from images row module"}},"31":{"type":"imagesRow","enabled":true,"collapsed":false,"fields":{"heading":"This is another heading"}}}}}','2020-01-29 19:44:04','2020-01-29 19:44:04','93897574-0a5d-4d91-844f-849c96682724'),
	(64,29,3,1,1,9,'','{"typeId":"3","authorId":null,"title":"Controllers","slug":"controllers","postDate":1580326620,"expiryDate":null,"enabled":true,"newParentId":null,"fields":{"1":[],"6":{"30":{"type":"imagesRow","enabled":true,"collapsed":false,"fields":{"heading":"This is a heading from images row module","images":{"32":{"type":"1","fields":{"image":["13"]}}}}}}}}','2020-01-29 19:59:24','2020-01-29 19:59:24','f130a7c6-4340-4593-9761-91cb54192557'),
	(65,29,3,1,1,10,NULL,'{"typeId":"3","authorId":null,"title":"Controllers","slug":"controllers","postDate":1580326620,"expiryDate":null,"enabled":"1","newParentId":null,"fields":{"1":[],"6":{"30":{"type":"imagesRow","enabled":"1","collapsed":false,"fields":{"heading":"This is a heading from images row module","images":{"32":{"type":"1","fields":{"image":["13"]}}}}}}}}','2020-01-29 20:03:22','2020-01-29 20:03:22','322ff072-3516-4dd9-957d-cd4da8c7b001');
UNLOCK TABLES;


LOCK TABLES `fieldgroups` WRITE;
INSERT INTO `fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,'Common','2019-05-23 15:26:20','2019-05-23 15:26:20','68199e24-9f96-4110-99b3-521d2387e9a7'),
	(2,'Rich Text Editor','2019-08-19 15:58:33','2019-08-19 15:58:33','47c428fa-7715-4ece-9388-567c4a7a800a'),
	(3,'Imagery','2019-08-19 19:41:05','2019-08-19 19:41:05','4e1b50b5-9b85-42ee-a8fd-c09e63504c12'),
	(4,'Modules','2020-01-29 19:33:30','2020-01-29 19:33:42','b4f0efc7-0ef5-40e2-8417-376d128a5334');
UNLOCK TABLES;


LOCK TABLES `fieldlayouttabs` WRITE;
INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,1,'Tab 1',1,'2019-06-17 17:19:25','2019-06-17 17:19:25','9a22128c-53f8-447e-af77-71b9393ec8c6'),
	(9,3,'Content',1,'2019-08-19 18:16:00','2019-08-19 18:16:00','d1e420ce-bbcb-4fa1-90cc-4d061319d0f8'),
	(15,2,'Content',1,'2019-08-19 20:25:37','2019-08-19 20:25:37','6162178c-b60b-4886-9b17-cfd564ed96c6'),
	(17,5,'Content',1,'2020-01-29 19:38:22','2020-01-29 19:38:22','85e138a7-e6e8-4953-bdc2-8d83e4fc3e2d'),
	(19,6,'Content',1,'2020-01-29 19:58:59','2020-01-29 19:58:59','389bd359-a25e-4ec4-ab7f-e78bead6f815'),
	(20,4,'Content',1,'2020-01-29 19:58:59','2020-01-29 19:58:59','19853f3a-bc7e-40d3-89c1-7a0918ea4a77');
UNLOCK TABLES;


LOCK TABLES `fields` WRITE;
INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,1,'Copy','copy','global','',1,'site',NULL,'craft\\fields\\Entries','{"sources":"*","source":null,"targetSiteId":null,"viewMode":null,"limit":"","selectionLabel":"","localizeRelations":false}','2019-06-17 17:19:02','2019-06-17 17:19:02','461e9cf7-1716-48da-b901-96778dcbd3c6'),
	(3,2,'Content Entry','contentEntry','global','',1,'none',NULL,'craft\\redactor\\Field','{"redactorConfig":"Standard.json","purifierConfig":"","cleanupHtml":true,"removeInlineStyles":"1","removeEmptyTags":"1","removeNbsp":"1","purifyHtml":"1","columnType":"text","availableVolumes":"*","availableTransforms":"*"}','2019-08-19 17:31:22','2019-08-19 17:31:22','1e17d042-e5d1-4fa1-8582-29ceb77f70df'),
	(5,3,'Images','images','global','',1,'site',NULL,'craft\\fields\\Assets','{"useSingleFolder":"","defaultUploadLocationSource":"volume:c416baed-fb8d-4319-8775-fe5d7e7c3d53","defaultUploadLocationSubpath":"","singleUploadLocationSource":"volume:c416baed-fb8d-4319-8775-fe5d7e7c3d53","singleUploadLocationSubpath":"","restrictFiles":"","allowedKinds":null,"sources":"*","source":null,"targetSiteId":null,"viewMode":"list","limit":"","selectionLabel":"","localizeRelations":false}','2019-08-19 19:41:36','2019-08-19 20:16:32','cb4505cb-bf15-4294-801d-4a61249fa278'),
	(6,4,'Modules','modules','global','',1,'site',NULL,'craft\\fields\\Matrix','{"minBlocks":"","maxBlocks":"","contentTable":"{{%matrixcontent_modules}}","localizeBlocks":false}','2020-01-29 19:36:31','2020-01-29 19:58:59','c9b114d4-d16c-4b01-956d-ce684a0f5fe1'),
	(7,NULL,'Heading','heading','matrixBlockType:d1a608ea-4046-44a3-9df4-b5f8fa9815fe','',0,'none',NULL,'craft\\fields\\PlainText','{"placeholder":"","code":"","multiline":"","initialRows":"4","charLimit":"","columnType":"text"}','2020-01-29 19:36:31','2020-01-29 19:58:59','a11e5702-a603-40f4-b935-8cb946bf2d98'),
	(8,NULL,'Images','images','matrixBlockType:d1a608ea-4046-44a3-9df4-b5f8fa9815fe','',1,'site',NULL,'verbb\\supertable\\fields\\SuperTableField','{"minRows":"","maxRows":"","contentTable":"{{%stc_1_images}}","localizeBlocks":false,"staticField":"","fieldLayout":"table","selectionLabel":""}','2020-01-29 19:58:59','2020-01-29 19:58:59','e58f8ea4-0caf-4081-9fda-ed2dd38a9661'),
	(9,NULL,'Image','image','superTableBlockType:bfa73f7f-ca2e-4baa-9ed1-54ba895f163f','Required dimensions: 297px x 231px',1,'site',NULL,'craft\\fields\\Assets','{"useSingleFolder":"","defaultUploadLocationSource":"volume:c416baed-fb8d-4319-8775-fe5d7e7c3d53","defaultUploadLocationSubpath":"","singleUploadLocationSource":"volume:c416baed-fb8d-4319-8775-fe5d7e7c3d53","singleUploadLocationSubpath":"","restrictFiles":"1","allowedKinds":["image"],"sources":"*","source":null,"targetSiteId":null,"viewMode":"list","limit":"1","selectionLabel":"","localizeRelations":false}','2020-01-29 19:58:59','2020-01-29 19:58:59','7123c0ec-ad37-459b-ac8a-6ab5e0f7f34d');
UNLOCK TABLES;


LOCK TABLES `fieldlayoutfields` WRITE;
INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,1,1,1,0,1,'2019-06-17 17:19:25','2019-06-17 17:19:25','56bf17b3-100a-4e20-b1c8-5e6541db4cf2'),
	(21,2,15,5,0,1,'2019-08-19 20:25:37','2019-08-19 20:25:37','b2f63d5f-8eea-4f1b-bba5-9b40a55c5dd1'),
	(22,2,15,3,0,2,'2019-08-19 20:25:37','2019-08-19 20:25:37','50ef10d7-f034-4969-bd71-f9a27a9cf240'),
	(24,5,17,1,0,1,'2020-01-29 19:38:22','2020-01-29 19:38:22','53b667de-0172-4bd1-bd16-e12d521c4f67'),
	(25,5,17,6,0,2,'2020-01-29 19:38:22','2020-01-29 19:38:22','d6ce2152-36c3-4fe8-991c-d3c7067c2da5'),
	(27,6,19,9,0,1,'2020-01-29 19:58:59','2020-01-29 19:58:59','5ef30bc4-f743-4e73-a21f-1473edcfc5c7'),
	(28,4,20,7,0,1,'2020-01-29 19:58:59','2020-01-29 19:58:59','5c3816ad-da42-4a1e-a204-0f89891b8135'),
	(29,4,20,8,0,2,'2020-01-29 19:58:59','2020-01-29 19:58:59','49dacbf1-c7ce-49ba-b04a-3f7cb07af590');
UNLOCK TABLES;


LOCK TABLES `globalsets` WRITE;
UNLOCK TABLES;


LOCK TABLES `info` WRITE;
INSERT INTO `info` (`id`, `version`, `schemaVersion`, `maintenance`, `config`, `configMap`, `fieldVersion`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,'3.1.30','3.1.28',0,'a:13:{s:11:"fieldGroups";a:4:{s:36:"68199e24-9f96-4110-99b3-521d2387e9a7";a:1:{s:4:"name";s:6:"Common";}s:36:"47c428fa-7715-4ece-9388-567c4a7a800a";a:1:{s:4:"name";s:16:"Rich Text Editor";}s:36:"4e1b50b5-9b85-42ee-a8fd-c09e63504c12";a:1:{s:4:"name";s:7:"Imagery";}s:36:"b4f0efc7-0ef5-40e2-8417-376d128a5334";a:1:{s:4:"name";s:7:"Modules";}}s:10:"siteGroups";a:1:{s:36:"e39f71de-1042-4704-a00b-8c0259b85b9f";a:1:{s:4:"name";s:5:"Craft";}}s:5:"sites";a:1:{s:36:"d75216f4-5e35-406f-a4e9-13e077287499";a:8:{s:7:"baseUrl";s:17:"$DEFAULT_SITE_URL";s:6:"handle";s:7:"default";s:7:"hasUrls";b:1;s:8:"language";s:5:"en-US";s:4:"name";s:5:"Craft";s:7:"primary";b:1;s:9:"siteGroup";s:36:"e39f71de-1042-4704-a00b-8c0259b85b9f";s:9:"sortOrder";i:1;}}s:5:"email";a:3:{s:9:"fromEmail";s:23:"dgaebel@trendyminds.com";s:8:"fromName";s:5:"Craft";s:13:"transportType";s:37:"craft\\mail\\transportadapters\\Sendmail";}s:6:"system";a:5:{s:7:"edition";s:4:"solo";s:4:"name";s:5:"Craft";s:4:"live";b:1;s:13:"schemaVersion";s:6:"3.1.28";s:8:"timeZone";s:19:"America/Los_Angeles";}s:5:"users";a:5:{s:24:"requireEmailVerification";b:1;s:23:"allowPublicRegistration";b:0;s:12:"defaultGroup";N;s:14:"photoVolumeUid";N;s:12:"photoSubpath";s:0:"";}s:12:"dateModified";i:1580328202;s:7:"plugins";a:3:{s:8:"molecule";a:3:{s:7:"edition";s:8:"standard";s:7:"enabled";b:1;s:13:"schemaVersion";s:5:"1.0.0";}s:8:"redactor";a:3:{s:7:"edition";s:8:"standard";s:7:"enabled";b:1;s:13:"schemaVersion";s:5:"2.3.0";}s:11:"super-table";a:3:{s:7:"edition";s:8:"standard";s:7:"enabled";b:1;s:13:"schemaVersion";s:6:"2.0.12";}}s:8:"sections";a:3:{s:36:"6ea80f24-bc86-4c5e-aa70-8d6079116ff2";a:7:{s:4:"name";s:4:"Home";s:6:"handle";s:4:"home";s:4:"type";s:6:"single";s:16:"enableVersioning";b:1;s:16:"propagateEntries";b:1;s:12:"siteSettings";a:1:{s:36:"d75216f4-5e35-406f-a4e9-13e077287499";a:4:{s:16:"enabledByDefault";b:1;s:7:"hasUrls";b:1;s:9:"uriFormat";s:8:"__home__";s:8:"template";s:5:"index";}}s:10:"entryTypes";a:1:{s:36:"391c90b0-7dbf-4919-a1a7-7bee13fc18a8";a:7:{s:4:"name";s:4:"Home";s:6:"handle";s:4:"home";s:13:"hasTitleField";b:0;s:10:"titleLabel";s:0:"";s:11:"titleFormat";s:18:"{section.name|raw}";s:9:"sortOrder";i:1;s:12:"fieldLayouts";a:1:{s:36:"b756f14d-60fb-427a-b4b5-58fe0b055fcb";a:1:{s:4:"tabs";a:1:{i:0;a:3:{s:4:"name";s:5:"Tab 1";s:9:"sortOrder";i:1;s:6:"fields";a:1:{s:36:"461e9cf7-1716-48da-b901-96778dcbd3c6";a:2:{s:8:"required";b:0;s:9:"sortOrder";i:1;}}}}}}}}}s:36:"f52db722-5a93-4a55-92f0-85859fa0f486";a:7:{s:4:"name";s:16:"Image Transforms";s:6:"handle";s:15:"imageTransforms";s:4:"type";s:6:"single";s:16:"enableVersioning";b:1;s:16:"propagateEntries";b:1;s:12:"siteSettings";a:1:{s:36:"d75216f4-5e35-406f-a4e9-13e077287499";a:4:{s:16:"enabledByDefault";b:1;s:7:"hasUrls";b:1;s:9:"uriFormat";s:7:"/{slug}";s:8:"template";s:27:"image-transforms/index.html";}}s:10:"entryTypes";a:1:{s:36:"859f27d2-5570-4602-b0f9-8bb42c39ffa1";a:7:{s:4:"name";s:16:"Image Transforms";s:6:"handle";s:15:"imageTransforms";s:13:"hasTitleField";b:1;s:10:"titleLabel";s:5:"Title";s:11:"titleFormat";s:0:"";s:9:"sortOrder";i:1;s:12:"fieldLayouts";a:1:{s:36:"4c88a662-12c5-47e1-ad01-e2f78eb49a77";a:1:{s:4:"tabs";a:1:{i:0;a:3:{s:4:"name";s:7:"Content";s:9:"sortOrder";i:1;s:6:"fields";a:2:{s:36:"cb4505cb-bf15-4294-801d-4a61249fa278";a:2:{s:8:"required";b:0;s:9:"sortOrder";i:1;}s:36:"1e17d042-e5d1-4fa1-8582-29ceb77f70df";a:2:{s:8:"required";b:0;s:9:"sortOrder";i:2;}}}}}}}}}s:36:"b40e8623-76b5-4398-a5f4-6f50c3b71ce1";a:7:{s:4:"name";s:11:"Controllers";s:6:"handle";s:11:"controllers";s:4:"type";s:6:"single";s:16:"enableVersioning";b:1;s:16:"propagateEntries";b:1;s:12:"siteSettings";a:1:{s:36:"d75216f4-5e35-406f-a4e9-13e077287499";a:4:{s:16:"enabledByDefault";b:1;s:7:"hasUrls";b:1;s:9:"uriFormat";s:7:"/{slug}";s:8:"template";s:17:"controllers/index";}}s:10:"entryTypes";a:1:{s:36:"04924666-665d-466d-8dc8-ba0d330c4fd2";a:7:{s:4:"name";s:11:"Controllers";s:6:"handle";s:11:"controllers";s:13:"hasTitleField";b:0;s:10:"titleLabel";s:0:"";s:11:"titleFormat";s:18:"{section.name|raw}";s:9:"sortOrder";i:1;s:12:"fieldLayouts";a:1:{s:36:"dbbb003e-3bc2-4d77-9b49-6ed463a62267";a:1:{s:4:"tabs";a:1:{i:0;a:3:{s:4:"name";s:7:"Content";s:9:"sortOrder";i:1;s:6:"fields";a:2:{s:36:"461e9cf7-1716-48da-b901-96778dcbd3c6";a:2:{s:8:"required";b:0;s:9:"sortOrder";i:1;}s:36:"c9b114d4-d16c-4b01-956d-ce684a0f5fe1";a:2:{s:8:"required";b:0;s:9:"sortOrder";i:2;}}}}}}}}}}s:6:"fields";a:4:{s:36:"461e9cf7-1716-48da-b901-96778dcbd3c6";a:10:{s:4:"name";s:4:"Copy";s:6:"handle";s:4:"copy";s:12:"instructions";s:0:"";s:10:"searchable";b:1;s:17:"translationMethod";s:4:"site";s:20:"translationKeyFormat";N;s:4:"type";s:20:"craft\\fields\\Entries";s:8:"settings";a:7:{s:7:"sources";s:1:"*";s:6:"source";N;s:12:"targetSiteId";N;s:8:"viewMode";N;s:5:"limit";s:0:"";s:14:"selectionLabel";s:0:"";s:17:"localizeRelations";b:0;}s:17:"contentColumnType";s:6:"string";s:10:"fieldGroup";s:36:"68199e24-9f96-4110-99b3-521d2387e9a7";}s:36:"1e17d042-e5d1-4fa1-8582-29ceb77f70df";a:10:{s:4:"name";s:13:"Content Entry";s:6:"handle";s:12:"contentEntry";s:12:"instructions";s:0:"";s:10:"searchable";b:1;s:17:"translationMethod";s:4:"none";s:20:"translationKeyFormat";N;s:4:"type";s:20:"craft\\redactor\\Field";s:8:"settings";a:10:{s:14:"redactorConfig";s:13:"Standard.json";s:14:"purifierConfig";s:0:"";s:11:"cleanupHtml";b:1;s:18:"removeInlineStyles";s:1:"1";s:15:"removeEmptyTags";s:1:"1";s:10:"removeNbsp";s:1:"1";s:10:"purifyHtml";s:1:"1";s:10:"columnType";s:4:"text";s:16:"availableVolumes";s:1:"*";s:19:"availableTransforms";s:1:"*";}s:17:"contentColumnType";s:4:"text";s:10:"fieldGroup";s:36:"47c428fa-7715-4ece-9388-567c4a7a800a";}s:36:"cb4505cb-bf15-4294-801d-4a61249fa278";a:10:{s:4:"name";s:6:"Images";s:6:"handle";s:6:"images";s:12:"instructions";s:0:"";s:10:"searchable";b:1;s:17:"translationMethod";s:4:"site";s:20:"translationKeyFormat";N;s:4:"type";s:19:"craft\\fields\\Assets";s:8:"settings";a:14:{s:15:"useSingleFolder";s:0:"";s:27:"defaultUploadLocationSource";s:43:"volume:c416baed-fb8d-4319-8775-fe5d7e7c3d53";s:28:"defaultUploadLocationSubpath";s:0:"";s:26:"singleUploadLocationSource";s:43:"volume:c416baed-fb8d-4319-8775-fe5d7e7c3d53";s:27:"singleUploadLocationSubpath";s:0:"";s:13:"restrictFiles";s:0:"";s:12:"allowedKinds";N;s:7:"sources";s:1:"*";s:6:"source";N;s:12:"targetSiteId";N;s:8:"viewMode";s:4:"list";s:5:"limit";s:0:"";s:14:"selectionLabel";s:0:"";s:17:"localizeRelations";b:0;}s:17:"contentColumnType";s:6:"string";s:10:"fieldGroup";s:36:"4e1b50b5-9b85-42ee-a8fd-c09e63504c12";}s:36:"c9b114d4-d16c-4b01-956d-ce684a0f5fe1";a:10:{s:4:"name";s:7:"Modules";s:6:"handle";s:7:"modules";s:12:"instructions";s:0:"";s:10:"searchable";b:1;s:17:"translationMethod";s:4:"site";s:20:"translationKeyFormat";N;s:4:"type";s:19:"craft\\fields\\Matrix";s:8:"settings";a:4:{s:9:"minBlocks";s:0:"";s:9:"maxBlocks";s:0:"";s:12:"contentTable";s:26:"{{%matrixcontent_modules}}";s:14:"localizeBlocks";b:0;}s:17:"contentColumnType";s:6:"string";s:10:"fieldGroup";s:36:"b4f0efc7-0ef5-40e2-8417-376d128a5334";}}s:7:"volumes";a:1:{s:36:"c416baed-fb8d-4319-8775-fe5d7e7c3d53";a:7:{s:4:"name";s:7:"uploads";s:6:"handle";s:7:"uploads";s:4:"type";s:19:"craft\\volumes\\Local";s:7:"hasUrls";b:1;s:3:"url";s:7:"/images";s:8:"settings";a:1:{s:4:"path";s:18:"$LOCAL_ASSETS_PATH";}s:9:"sortOrder";i:3;}}s:16:"matrixBlockTypes";a:1:{s:36:"d1a608ea-4046-44a3-9df4-b5f8fa9815fe";a:6:{s:5:"field";s:36:"c9b114d4-d16c-4b01-956d-ce684a0f5fe1";s:4:"name";s:10:"Images Row";s:6:"handle";s:9:"imagesRow";s:9:"sortOrder";i:1;s:6:"fields";a:2:{s:36:"a11e5702-a603-40f4-b935-8cb946bf2d98";a:10:{s:4:"name";s:7:"Heading";s:6:"handle";s:7:"heading";s:12:"instructions";s:0:"";s:10:"searchable";b:0;s:17:"translationMethod";s:4:"none";s:20:"translationKeyFormat";N;s:4:"type";s:22:"craft\\fields\\PlainText";s:8:"settings";a:6:{s:11:"placeholder";s:0:"";s:4:"code";s:0:"";s:9:"multiline";s:0:"";s:11:"initialRows";s:1:"4";s:9:"charLimit";s:0:"";s:10:"columnType";s:4:"text";}s:17:"contentColumnType";s:4:"text";s:10:"fieldGroup";N;}s:36:"e58f8ea4-0caf-4081-9fda-ed2dd38a9661";a:10:{s:4:"name";s:6:"Images";s:6:"handle";s:6:"images";s:12:"instructions";s:0:"";s:10:"searchable";b:1;s:17:"translationMethod";s:4:"site";s:20:"translationKeyFormat";N;s:4:"type";s:39:"verbb\\supertable\\fields\\SuperTableField";s:8:"settings";a:7:{s:7:"minRows";s:0:"";s:7:"maxRows";s:0:"";s:12:"contentTable";s:17:"{{%stc_1_images}}";s:14:"localizeBlocks";b:0;s:11:"staticField";s:0:"";s:11:"fieldLayout";s:5:"table";s:14:"selectionLabel";s:0:"";}s:17:"contentColumnType";s:6:"string";s:10:"fieldGroup";N;}}s:12:"fieldLayouts";a:1:{s:36:"074a45da-7356-48b8-8b09-d88f9016cb1b";a:1:{s:4:"tabs";a:1:{i:0;a:3:{s:4:"name";s:7:"Content";s:9:"sortOrder";i:1;s:6:"fields";a:2:{s:36:"a11e5702-a603-40f4-b935-8cb946bf2d98";a:2:{s:8:"required";b:0;s:9:"sortOrder";i:1;}s:36:"e58f8ea4-0caf-4081-9fda-ed2dd38a9661";a:2:{s:8:"required";b:0;s:9:"sortOrder";i:2;}}}}}}}}s:20:"superTableBlockTypes";a:1:{s:36:"bfa73f7f-ca2e-4baa-9ed1-54ba895f163f";a:3:{s:5:"field";s:36:"e58f8ea4-0caf-4081-9fda-ed2dd38a9661";s:6:"fields";a:1:{s:36:"7123c0ec-ad37-459b-ac8a-6ab5e0f7f34d";a:10:{s:4:"name";s:5:"Image";s:6:"handle";s:5:"image";s:12:"instructions";s:34:"Required dimensions: 297px x 231px";s:10:"searchable";b:1;s:17:"translationMethod";s:4:"site";s:20:"translationKeyFormat";N;s:4:"type";s:19:"craft\\fields\\Assets";s:8:"settings";a:14:{s:15:"useSingleFolder";s:0:"";s:27:"defaultUploadLocationSource";s:43:"volume:c416baed-fb8d-4319-8775-fe5d7e7c3d53";s:28:"defaultUploadLocationSubpath";s:0:"";s:26:"singleUploadLocationSource";s:43:"volume:c416baed-fb8d-4319-8775-fe5d7e7c3d53";s:27:"singleUploadLocationSubpath";s:0:"";s:13:"restrictFiles";s:1:"1";s:12:"allowedKinds";a:1:{i:0;s:5:"image";}s:7:"sources";s:1:"*";s:6:"source";N;s:12:"targetSiteId";N;s:8:"viewMode";s:4:"list";s:5:"limit";s:1:"1";s:14:"selectionLabel";s:0:"";s:17:"localizeRelations";b:0;}s:17:"contentColumnType";s:6:"string";s:10:"fieldGroup";N;}}s:12:"fieldLayouts";a:1:{s:36:"cf0fe66e-180e-4664-8d9d-9f176ae37dac";a:1:{s:4:"tabs";a:1:{i:0;a:3:{s:4:"name";s:7:"Content";s:9:"sortOrder";i:1;s:6:"fields";a:1:{s:36:"7123c0ec-ad37-459b-ac8a-6ab5e0f7f34d";a:2:{s:8:"required";b:0;s:9:"sortOrder";i:1;}}}}}}}}}','[]','9ATA6FIZrt7p','2019-05-23 15:26:20','2020-01-29 20:03:23','9187c062-f6f3-4a3c-a62d-00566b968cb4');
UNLOCK TABLES;


LOCK TABLES `matrixblocktypes` WRITE;
INSERT INTO `matrixblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,6,4,'Images Row','imagesRow',1,'2020-01-29 19:36:31','2020-01-29 19:58:59','d1a608ea-4046-44a3-9df4-b5f8fa9815fe');
UNLOCK TABLES;


LOCK TABLES `matrixblocks` WRITE;
INSERT INTO `matrixblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `sortOrder`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(30,29,NULL,6,1,1,NULL,'2020-01-29 19:38:40','2020-01-29 20:03:23','f6dc7b89-5de1-4507-abcb-380bb10895e5'),
	(31,29,NULL,6,1,2,0,'2020-01-29 19:43:14','2020-01-29 19:46:04','9f281f42-37f4-489a-a229-2ac582ec7d3e');
UNLOCK TABLES;


LOCK TABLES `matrixcontent_modules` WRITE;
INSERT INTO `matrixcontent_modules` (`id`, `elementId`, `siteId`, `dateCreated`, `dateUpdated`, `uid`, `field_imagesRow_heading`) VALUES 
	(1,30,1,'2020-01-29 19:38:40','2020-01-29 20:03:22','fd85093a-28c6-4041-ab37-e68587a2f58d','This is a heading from images row module'),
	(2,31,1,'2020-01-29 19:43:14','2020-01-29 19:46:04','1ad815b1-984d-4f33-a1e4-9ff6cf5f3fee','This is another heading');
UNLOCK TABLES;


LOCK TABLES `plugins` WRITE;
INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,'molecule','1.2.0','1.0.0','unknown',NULL,'2019-05-23 15:32:42','2019-05-23 15:32:42','2020-05-28 12:56:48','ca2b9c63-1217-4657-9681-80181ec087c3'),
	(2,'redactor','2.3.3.2','2.3.0','unknown',NULL,'2019-08-19 15:56:33','2019-08-19 15:56:33','2020-05-28 12:56:48','d2b95002-6fc9-4c91-9cc7-fd6e7a7883ac'),
	(3,'super-table','2.1.21','2.0.12','unknown',NULL,'2020-01-29 19:51:45','2020-01-29 19:51:45','2020-05-28 12:56:48','91735eea-33be-4c8e-bac7-7f24d6a281f1');
UNLOCK TABLES;


LOCK TABLES `migrations` WRITE;
INSERT INTO `migrations` (`id`, `pluginId`, `type`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,NULL,'app','Install','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','2a7566d2-cf47-47d7-a308-1d0f5ee444ce'),
	(2,NULL,'app','m150403_183908_migrations_table_changes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','394ea745-18fa-4863-946a-46af4b8a6a9c'),
	(3,NULL,'app','m150403_184247_plugins_table_changes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','d2d238b1-df35-4005-8dd9-a87ee6a14687'),
	(4,NULL,'app','m150403_184533_field_version','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','60db24af-a71b-46a9-92ec-5c2939e16e9d'),
	(5,NULL,'app','m150403_184729_type_columns','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','8fabb1c2-bc17-468b-9fb8-2097dd467806'),
	(6,NULL,'app','m150403_185142_volumes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','1e2b4b17-60f3-4dc3-8564-e0b67aefc9e5'),
	(7,NULL,'app','m150428_231346_userpreferences','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','dba79b0e-17c7-40eb-8110-0dd65abcfeee'),
	(8,NULL,'app','m150519_150900_fieldversion_conversion','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','18babaa4-a527-46c5-94be-cd678a3c51d1'),
	(9,NULL,'app','m150617_213829_update_email_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','cbc190b8-782c-4116-8a0b-45a66397d024'),
	(10,NULL,'app','m150721_124739_templatecachequeries','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','9fc6b0ff-abc8-4a0e-91ce-644620285b57'),
	(11,NULL,'app','m150724_140822_adjust_quality_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','522cd82f-4f44-46a4-befc-709857b68217'),
	(12,NULL,'app','m150815_133521_last_login_attempt_ip','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','811eb4bb-bc5a-43f8-8a44-cb629bbd8aa8'),
	(13,NULL,'app','m151002_095935_volume_cache_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','1766e235-907f-436c-9006-b31f864f2761'),
	(14,NULL,'app','m151005_142750_volume_s3_storage_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','a69e2353-ea7a-4a9b-aa15-927a5646738d'),
	(15,NULL,'app','m151016_133600_delete_asset_thumbnails','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','d4d0c649-dfcc-46cd-8d40-7bec34fadf82'),
	(16,NULL,'app','m151209_000000_move_logo','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','86a0a59a-6c19-4df5-8142-16cef10c574f'),
	(17,NULL,'app','m151211_000000_rename_fileId_to_assetId','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','ca26816e-99b2-4c96-adf8-1f4948505307'),
	(18,NULL,'app','m151215_000000_rename_asset_permissions','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','3e36c650-ac22-4182-8ad0-6570ff2c7a1c'),
	(19,NULL,'app','m160707_000001_rename_richtext_assetsource_setting','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','19561a70-6b73-4970-a1ba-b48136718f41'),
	(20,NULL,'app','m160708_185142_volume_hasUrls_setting','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','12f9cddf-f10b-46e9-9a39-67f006f89770'),
	(21,NULL,'app','m160714_000000_increase_max_asset_filesize','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','3a23de36-dea7-4ca3-af6d-4fe26cadd403'),
	(22,NULL,'app','m160727_194637_column_cleanup','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','1fd101aa-62d8-4e51-93bf-cdd04edaf22c'),
	(23,NULL,'app','m160804_110002_userphotos_to_assets','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','28e7256d-2304-4d1d-b52f-d8a143e11323'),
	(24,NULL,'app','m160807_144858_sites','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','8f45891c-04bf-45f0-b175-7e0e0b94a0f5'),
	(25,NULL,'app','m160829_000000_pending_user_content_cleanup','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','63b3261d-061f-4477-9279-45916d5bdf18'),
	(26,NULL,'app','m160830_000000_asset_index_uri_increase','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','f4ff324e-63c6-4754-9bdf-7d1fb6a64f73'),
	(27,NULL,'app','m160912_230520_require_entry_type_id','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','e5861ebc-764f-4cbb-9ed9-3fdc4e8eee28'),
	(28,NULL,'app','m160913_134730_require_matrix_block_type_id','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','568ad030-9b7b-483a-9bea-fd97673a1002'),
	(29,NULL,'app','m160920_174553_matrixblocks_owner_site_id_nullable','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','e25b4c2e-a2ce-48ff-bfa2-f36861aa1688'),
	(30,NULL,'app','m160920_231045_usergroup_handle_title_unique','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','4f9ed4ce-4f1f-4d31-9a20-5e027f5a84cb'),
	(31,NULL,'app','m160925_113941_route_uri_parts','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','2126ba12-e003-4aaa-a419-8a1e5cf3a507'),
	(32,NULL,'app','m161006_205918_schemaVersion_not_null','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','d4f4df61-3454-4975-a355-feb13fbde31b'),
	(33,NULL,'app','m161007_130653_update_email_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','f6d4ae02-da26-4a59-a702-121816150452'),
	(34,NULL,'app','m161013_175052_newParentId','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','81014ba3-b13a-4dda-8f13-c77102113a93'),
	(35,NULL,'app','m161021_102916_fix_recent_entries_widgets','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','69d08a00-0e02-4e4d-9203-eb548bf80746'),
	(36,NULL,'app','m161021_182140_rename_get_help_widget','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','0ad35fd7-51d8-49c7-8132-1f573fe605d5'),
	(37,NULL,'app','m161025_000000_fix_char_columns','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','13e4123f-f6b3-4aca-b7ec-f1d6aebd464a'),
	(38,NULL,'app','m161029_124145_email_message_languages','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','aba84036-7883-4ced-9f32-40bc79b463a3'),
	(39,NULL,'app','m161108_000000_new_version_format','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','57dd1eea-9a06-446f-a6ab-6ffd94798cdf'),
	(40,NULL,'app','m161109_000000_index_shuffle','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','d8b5128c-f04b-4209-a6f6-3bd160f12436'),
	(41,NULL,'app','m161122_185500_no_craft_app','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','6a061beb-1792-4f92-8d2f-c383dce148d2'),
	(42,NULL,'app','m161125_150752_clear_urlmanager_cache','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','5a65e6a7-9528-416b-8f45-9f68427b234b'),
	(43,NULL,'app','m161220_000000_volumes_hasurl_notnull','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','b5570338-cc82-4520-815b-2e13c048eece'),
	(44,NULL,'app','m170114_161144_udates_permission','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','741754b0-4a1f-4dce-8a84-f6a3e11f9993'),
	(45,NULL,'app','m170120_000000_schema_cleanup','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','e64ef3da-53bf-4e2e-a482-86475cc6df41'),
	(46,NULL,'app','m170126_000000_assets_focal_point','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','fc523baf-3e6f-4aaa-b46a-1a596b8ae9d8'),
	(47,NULL,'app','m170206_142126_system_name','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','ce3a0a98-5b9e-4c5b-8265-2816a4541b93'),
	(48,NULL,'app','m170217_044740_category_branch_limits','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','3fca5607-8030-41b2-ad3d-79d342c4b2a2'),
	(49,NULL,'app','m170217_120224_asset_indexing_columns','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','541ad5e0-5787-40a1-a5cd-4f00489f227e'),
	(50,NULL,'app','m170223_224012_plain_text_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','2d6f5ba3-a0a3-47c5-ae8e-001842118e67'),
	(51,NULL,'app','m170227_120814_focal_point_percentage','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','7437c304-ee5f-4cfb-b913-da50c4abd7ec'),
	(52,NULL,'app','m170228_171113_system_messages','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','3c58275e-d5e5-4b69-8575-c9df7dbccaf5'),
	(53,NULL,'app','m170303_140500_asset_field_source_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','3cf5c37b-d308-4f48-a654-f4ac1b2d6e4c'),
	(54,NULL,'app','m170306_150500_asset_temporary_uploads','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','504cb952-7769-4596-ba56-a9ce65e5f673'),
	(55,NULL,'app','m170523_190652_element_field_layout_ids','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','3ee9f2a9-fb01-4965-adf5-87ae07c90004'),
	(56,NULL,'app','m170612_000000_route_index_shuffle','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','22dcf6c9-f5e2-480e-b9b4-c84920cee553'),
	(57,NULL,'app','m170621_195237_format_plugin_handles','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','d4fb6b35-e9b0-478a-bb9c-56afcccc872f'),
	(58,NULL,'app','m170630_161027_deprecation_line_nullable','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','8e072405-6632-42fd-9db2-d46645130aee'),
	(59,NULL,'app','m170630_161028_deprecation_changes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','bbb7f401-f9ab-48f6-932f-31b46c8a39fa'),
	(60,NULL,'app','m170703_181539_plugins_table_tweaks','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','8950e8b3-5b96-442b-8e1b-0e376ef3ef2a'),
	(61,NULL,'app','m170704_134916_sites_tables','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','84721e05-b9bc-4645-a196-4fa6757ceed0'),
	(62,NULL,'app','m170706_183216_rename_sequences','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','88b83254-0a4e-4998-89d0-9f89f0859663'),
	(63,NULL,'app','m170707_094758_delete_compiled_traits','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','4da46b04-3296-433c-b4e2-bcded67055d6'),
	(64,NULL,'app','m170731_190138_drop_asset_packagist','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','e8cf0d25-2eeb-44b1-8920-01de5a419798'),
	(65,NULL,'app','m170810_201318_create_queue_table','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','a1cfe061-6e96-4196-98af-9d72d81a8a62'),
	(66,NULL,'app','m170816_133741_delete_compiled_behaviors','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','8e6a6469-092b-4229-9a89-56c580ee27b4'),
	(67,NULL,'app','m170903_192801_longblob_for_queue_jobs','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','61afe04a-c634-4df1-ae7e-e2bc8b417592'),
	(68,NULL,'app','m170914_204621_asset_cache_shuffle','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','9cfe1d5c-c1e0-43ab-a4e7-9db1fc3784f5'),
	(69,NULL,'app','m171011_214115_site_groups','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','e1c4db93-3701-4823-b22d-c280e9deb807'),
	(70,NULL,'app','m171012_151440_primary_site','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','8d83ffc9-5488-4272-a035-f6b19045036b'),
	(71,NULL,'app','m171013_142500_transform_interlace','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','53395e2c-50b3-49f6-9017-bb44a20b1895'),
	(72,NULL,'app','m171016_092553_drop_position_select','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','39e9abaf-0075-4daa-b08a-512c0ba7e441'),
	(73,NULL,'app','m171016_221244_less_strict_translation_method','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','a9e7ea6f-1057-4ae7-8ab1-10e5eedad6cc'),
	(74,NULL,'app','m171107_000000_assign_group_permissions','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','6612c5ac-a668-4765-853e-a8da43cdb90b'),
	(75,NULL,'app','m171117_000001_templatecache_index_tune','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','75d4c8a8-35c1-495c-9423-477a44b78687'),
	(76,NULL,'app','m171126_105927_disabled_plugins','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','42207618-7e0a-44ec-99b1-3c0e86836d5b'),
	(77,NULL,'app','m171130_214407_craftidtokens_table','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','28a99244-aac7-4048-a3ee-455c845e5857'),
	(78,NULL,'app','m171202_004225_update_email_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','97a0690c-5c49-4f76-8251-099fadca68ef'),
	(79,NULL,'app','m171204_000001_templatecache_index_tune_deux','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','d881940a-d41f-4766-95d6-ff520cf71749'),
	(80,NULL,'app','m171205_130908_remove_craftidtokens_refreshtoken_column','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','3ad6809e-ab10-4824-b4a5-a68ce082784b'),
	(81,NULL,'app','m171218_143135_longtext_query_column','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','e800d90f-1d7c-4f8a-a455-643aef977802'),
	(82,NULL,'app','m171231_055546_environment_variables_to_aliases','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','b61653a8-c013-4603-83ca-fbbea70ab432'),
	(83,NULL,'app','m180113_153740_drop_users_archived_column','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','6068b840-13d4-459d-be1e-52a803545a8f'),
	(84,NULL,'app','m180122_213433_propagate_entries_setting','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','8d341ea9-9d71-4b7f-8799-3d4603c70160'),
	(85,NULL,'app','m180124_230459_fix_propagate_entries_values','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','a26fe625-c31d-4ba3-a741-5a8b1225b797'),
	(86,NULL,'app','m180128_235202_set_tag_slugs','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','5315e5a4-dc72-4e20-a05f-715dd040f493'),
	(87,NULL,'app','m180202_185551_fix_focal_points','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','6f252401-9b0e-41e2-9d1a-d53c6246a31c'),
	(88,NULL,'app','m180217_172123_tiny_ints','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','0c989847-2114-4327-8811-b8b6e6cb2457'),
	(89,NULL,'app','m180321_233505_small_ints','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','57905460-e46b-42f1-934c-d4af4574d9a8'),
	(90,NULL,'app','m180328_115523_new_license_key_statuses','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','bf8f8c64-ccd9-4f53-afcf-ec84ae85baa4'),
	(91,NULL,'app','m180404_182320_edition_changes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','d85c9dd4-d359-43bc-a9c6-cb9cddd9c6e2'),
	(92,NULL,'app','m180411_102218_fix_db_routes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','1596d0da-4288-4fcd-b21e-023ae3155ca8'),
	(93,NULL,'app','m180416_205628_resourcepaths_table','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','bf9aec48-0870-436e-92e2-2e69289c7b1b'),
	(94,NULL,'app','m180418_205713_widget_cleanup','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','d4ae8c99-6d06-424d-9ccb-6c764a673b22'),
	(95,NULL,'app','m180425_203349_searchable_fields','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','a81c33ee-f48c-4233-a709-7ccd4ecc6b0c'),
	(96,NULL,'app','m180516_153000_uids_in_field_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','00dcf1a2-9a00-4bf0-86ff-877142bdc393'),
	(97,NULL,'app','m180517_173000_user_photo_volume_to_uid','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','4ea9be03-084f-4e0b-9ab6-a8a77a0e7e24'),
	(98,NULL,'app','m180518_173000_permissions_to_uid','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','0b41f656-c8bf-46da-904c-06f11f02a388'),
	(99,NULL,'app','m180520_173000_matrix_context_to_uids','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','db1307be-7e0b-4df3-b953-4901097e247d'),
	(100,NULL,'app','m180521_173000_initial_yml_and_snapshot','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','8c99d480-2e21-4a68-806a-a5370e21d67b'),
	(101,NULL,'app','m180731_162030_soft_delete_sites','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','80d4c01c-7fc7-40c0-8ad8-94d6dd7cf6b7'),
	(102,NULL,'app','m180810_214427_soft_delete_field_layouts','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','193183dc-056a-4474-a6c6-20248c78e27a'),
	(103,NULL,'app','m180810_214439_soft_delete_elements','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','d083d248-5eea-476e-ac6c-83f20ff65476'),
	(104,NULL,'app','m180824_193422_case_sensitivity_fixes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','91a7515b-131e-4aae-ae5f-f0ac18914b52'),
	(105,NULL,'app','m180901_151639_fix_matrixcontent_tables','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','627c3592-9db2-42c9-8ff9-af439138abdc'),
	(106,NULL,'app','m180904_112109_permission_changes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','2c2c4272-a643-4cac-80ff-047d3744a9a2'),
	(107,NULL,'app','m180910_142030_soft_delete_sitegroups','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','a904a984-c96e-4ec8-b93e-3c7c72fbf28d'),
	(108,NULL,'app','m181011_160000_soft_delete_asset_support','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','3eed29cc-7935-4fbd-ab0b-13766f4e6d03'),
	(109,NULL,'app','m181016_183648_set_default_user_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','c358215a-bf28-4dfc-badd-ac07100972f8'),
	(110,NULL,'app','m181017_225222_system_config_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','de02d1e3-8196-420d-974a-e59f740af7c2'),
	(111,NULL,'app','m181018_222343_drop_userpermissions_from_config','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','07040343-e731-4055-a5c9-5f4f3ce3aa05'),
	(112,NULL,'app','m181029_130000_add_transforms_routes_to_config','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','d257cd37-bb45-4219-862f-bdf09193b5f7'),
	(113,NULL,'app','m181112_203955_sequences_table','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','6349ff63-1ae6-4671-8169-68221a786d36'),
	(114,NULL,'app','m181121_001712_cleanup_field_configs','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','ebd35f7b-15d9-4522-b05d-8a5ebc8199b1'),
	(115,NULL,'app','m181128_193942_fix_project_config','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','ed9e1985-3998-4db6-8215-dbfc8315f8a1'),
	(116,NULL,'app','m181130_143040_fix_schema_version','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','627f9f87-e5a4-4b3c-b34a-67b1ea42d344'),
	(117,NULL,'app','m181211_143040_fix_entry_type_uids','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','ec996fc2-3160-4353-9800-43a6ecf61e04'),
	(118,NULL,'app','m181213_102500_config_map_aliases','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','b728ca67-7c6c-4d7e-b085-78478e071238'),
	(119,NULL,'app','m181217_153000_fix_structure_uids','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','ef0325fe-52dd-4e84-87ce-efb88e633dc0'),
	(120,NULL,'app','m190104_152725_store_licensed_plugin_editions','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','308ed929-2fbd-4fd1-a083-b0de6f8be64e'),
	(121,NULL,'app','m190108_110000_cleanup_project_config','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','1c28396d-df3e-46f5-b2f1-cc89de206560'),
	(122,NULL,'app','m190108_113000_asset_field_setting_change','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','fe0c379b-bb13-4ef5-b732-056ccf1ca40e'),
	(123,NULL,'app','m190109_172845_fix_colspan','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','b1663c54-fd3c-4d88-94be-79e6cec5da23'),
	(124,NULL,'app','m190110_150000_prune_nonexisting_sites','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','dae009c3-74f0-4cd1-abca-b37e385ad712'),
	(125,NULL,'app','m190110_214819_soft_delete_volumes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','7cf119a5-dc0e-4f68-9bcf-55e9d5e778c0'),
	(126,NULL,'app','m190112_124737_fix_user_settings','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','99f65baa-02ee-4528-8736-98101306eae3'),
	(127,NULL,'app','m190112_131225_fix_field_layouts','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','5d65a680-7560-4fdf-a358-5ea614d19309'),
	(128,NULL,'app','m190112_201010_more_soft_deletes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','3a1cca60-cf7a-4dc2-a7ed-4286aa2219d9'),
	(129,NULL,'app','m190114_143000_more_asset_field_setting_changes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','824422cf-2c63-4b92-a930-7e1b73444913'),
	(130,NULL,'app','m190121_120000_rich_text_config_setting','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','ff7e39e5-9dab-42ad-b04e-99cd30b3f877'),
	(131,NULL,'app','m190125_191628_fix_email_transport_password','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','448ea0c7-4a43-4790-9682-2afb6bd034f7'),
	(132,NULL,'app','m190128_181422_cleanup_volume_folders','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','50707ec9-359e-490d-a082-72fde2301114'),
	(133,NULL,'app','m190205_140000_fix_asset_soft_delete_index','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','f36483c3-f64b-401a-b019-52a17f116d91'),
	(134,NULL,'app','m190208_140000_reset_project_config_mapping','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','f0704481-c663-4f10-84e1-44098354cf8b'),
	(135,NULL,'app','m190218_143000_element_index_settings_uid','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','dcf8be8b-1ed6-469b-88a9-674983d4f0b0'),
	(136,NULL,'app','m190401_223843_drop_old_indexes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','6d9a72eb-35ba-4469-a112-a393afcb1dcd'),
	(137,NULL,'app','m190416_014525_drop_unique_global_indexes','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','716f8c5c-dd4f-4441-9066-2d8e2aace6fc'),
	(138,NULL,'app','m190502_122019_store_default_user_group_uid','2019-05-23 15:26:22','2019-05-23 15:26:22','2019-05-23 15:26:22','c6709244-b663-4952-b64e-03329b6309f6'),
	(139,2,'plugin','m180430_204710_remove_old_plugins','2019-08-19 15:56:33','2019-08-19 15:56:33','2019-08-19 15:56:33','5b88c7cd-fffe-41dd-b481-e19344176efc'),
	(140,2,'plugin','Install','2019-08-19 15:56:33','2019-08-19 15:56:33','2019-08-19 15:56:33','56fbe2d9-f6b9-44a2-a061-17ea3a79fd02'),
	(141,2,'plugin','m190225_003922_split_cleanup_html_settings','2019-08-19 15:56:33','2019-08-19 15:56:33','2019-08-19 15:56:33','bda6c33b-d550-4e8d-8d06-a61c309302b9'),
	(142,3,'plugin','Install','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','1ded011c-bb19-4c62-813c-af70af9c34b8'),
	(143,3,'plugin','m180210_000000_migrate_content_tables','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','a7308ee7-9eb0-46ba-b506-979b9eeee029'),
	(144,3,'plugin','m180211_000000_type_columns','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','a6e8fb44-d657-46b5-b631-b9e7a254aa05'),
	(145,3,'plugin','m180219_000000_sites','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','62f8b999-7311-4b23-ad9b-6969695d3983'),
	(146,3,'plugin','m180220_000000_fix_context','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','f3956b1f-376c-4b58-81bb-a60214ea8edd'),
	(147,3,'plugin','m190117_000000_soft_deletes','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','eab05c86-dbe9-4c37-a75a-f421c03db4ef'),
	(148,3,'plugin','m190117_000001_context_to_uids','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','96f83120-b886-4875-887e-0a2727d27491'),
	(149,3,'plugin','m190120_000000_fix_supertablecontent_tables','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','d26ffaf8-f4df-46e7-b1a9-7c627d5d3fff'),
	(150,3,'plugin','m190131_000000_fix_supertable_missing_fields','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','2ce1028d-c21c-4ac9-a91c-46e698f4d429'),
	(151,3,'plugin','m190227_100000_fix_project_config','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','460f0433-70ed-4350-af2d-0d5481194d42'),
	(152,3,'plugin','m190511_100000_fix_project_config','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','f7e5a245-73b6-44d2-9bba-a75d53ee9b72'),
	(153,3,'plugin','m190520_000000_fix_project_config','2020-01-29 19:51:45','2020-01-29 19:51:45','2020-01-29 19:51:45','589edb9d-ee04-40d7-8e56-0e1fce3234b1');
UNLOCK TABLES;


LOCK TABLES `queue` WRITE;
UNLOCK TABLES;


LOCK TABLES `relations` WRITE;
INSERT INTO `relations` (`id`, `fieldId`, `sourceId`, `sourceSiteId`, `targetId`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(3,5,11,NULL,12,1,'2019-08-19 19:45:44','2019-08-19 19:45:44','3862bbf8-2c59-4caf-a289-9bd6355669b3'),
	(4,5,11,NULL,13,2,'2019-08-19 19:45:44','2019-08-19 19:45:44','94683055-d6f6-42c8-a244-41720ad41163'),
	(11,5,19,NULL,13,1,'2019-08-19 20:19:49','2019-08-19 20:19:49','7e1df355-2092-4b4c-a789-4485e4d877bb'),
	(12,5,19,NULL,12,2,'2019-08-19 20:19:49','2019-08-19 20:19:49','819ec67c-0d98-4eb4-96d7-1b93273213dc'),
	(15,5,28,NULL,13,1,'2019-08-19 20:26:54','2019-08-19 20:26:54','9bfc4ca5-7b5a-48a5-85a5-0625b1857445'),
	(16,5,28,NULL,12,2,'2019-08-19 20:26:54','2019-08-19 20:26:54','1281eb9f-8407-43ae-8ce1-18a212a5129d'),
	(19,9,32,NULL,13,1,'2020-01-29 20:03:23','2020-01-29 20:03:23','7a11b730-7fe0-423e-b9a7-ed116f19302e');
UNLOCK TABLES;


LOCK TABLES `resourcepaths` WRITE;
INSERT INTO `resourcepaths` (`hash`, `path`) VALUES 
	('10afabb0','@craft/web/assets/utilities/dist'),
	('16a9bbe6','@lib/d3'),
	('180c9bb7','@lib/picturefill'),
	('1a13d8e','@craft/web/assets/cp/dist'),
	('1bdfe41f','@craft/web/assets/updateswidget/dist'),
	('1fa8a775','@lib/jquery-touch-events'),
	('2514ac60','@lib/garnishjs'),
	('2565a671','@craft/web/assets/recententries/dist'),
	('2b4c6cd1','@app/web/assets/clearcaches/dist'),
	('2ca6e02e','@craft/web/assets/updater/dist'),
	('3052785e','@lib/fabric'),
	('321d0438','@lib/timepicker'),
	('3320239b','@app/web/assets/dashboard/dist'),
	('3a17c07c','@app/web/assets/plugins/dist'),
	('4326a307','@craft/web/assets/pluginstore/dist'),
	('461ef2b9','@lib/xregexp'),
	('4a5d937a','@craft/web/assets/cp/dist'),
	('4a88742a','@vendor/craftcms/redactor/lib/redactor-plugins/fullscreen'),
	('4b1834bd','@lib/fileupload'),
	('4c72b633','@lib/selectize'),
	('50234aeb','@craft/web/assets/updateswidget/dist'),
	('5379ad32','@craft/web/assets/tablesettings/dist'),
	('5388d13d','@craft/web/assets/matrix/dist'),
	('53f03543','@lib/picturefill'),
	('54540981','@lib/jquery-touch-events'),
	('56d20308','@lib/prismjs'),
	('587a4f6f','@app/web/assets/editentry/dist'),
	('5b530544','@craft/web/assets/utilities/dist'),
	('5bf1bfb1','@verbb/supertable/resources/dist'),
	('5d551512','@lib/d3'),
	('66a438e5','@craft/icons'),
	('675a4eda','@craft/web/assets/updater/dist'),
	('6e990885','@craft/web/assets/recententries/dist'),
	('6ee80294','@lib/garnishjs'),
	('78dc8d6f','@app/web/assets/dashboard/dist'),
	('78e18c7','@lib/selectize'),
	('7b6b1f47','@craft/web/assets/fields/dist'),
	('7baed6aa','@lib/fabric'),
	('7ddd8ecc','@vendor/craftcms/redactor/lib/redactor-plugins/video'),
	('7fbba321','@app/web/assets/fields/dist'),
	('807c651c','@lib/jquery-ui'),
	('83662f52','@craft/web/assets/feed/dist'),
	('8529504d','@lib/velocity'),
	('8808f83b','@craft/web/assets/updates/dist'),
	('89362669','@app/web/assets/feed/dist'),
	('8a0254da','@craft/redactor/assets/field/dist'),
	('8da0df3','@craft/web/assets/pluginstore/dist'),
	('94a6a730','@bower/jquery/dist'),
	('96b40a01','@app/web/assets/craftsupport/dist'),
	('9826a6c0','@app/web/assets/updateswidget/dist'),
	('990effa5','@lib/jquery.payment'),
	('9ec2d4ad','@craft/web/assets/plugins/dist'),
	('a0e98e08','@app/web/assets/pluginstore/dist'),
	('a69ce4ae','@app/web/assets/recententries/dist'),
	('a907bdbb','@app/web/assets/assetindexes/dist'),
	('ac8c66c8','@lib'),
	('b1d9a76d','@craft/web/assets/dashboard/dist'),
	('b475a5db','@craft/web/assets/login/dist'),
	('bb360cc5','@lib/element-resize-detector'),
	('bbd1c323','@app/web/assets/cp/dist'),
	('bc731216','@craft/web/assets/craftsupport/dist'),
	('bfefd65d','@app/web/assets/login/dist'),
	('c2ca889d','@app/web/assets/feed/dist'),
	('c38f5a0b','@app/web/assets/updater/dist'),
	('c3f456cf','@craft/web/assets/updates/dist'),
	('c5d84c5a','@app/web/assets/installer/dist'),
	('c89a81a6','@craft/web/assets/feed/dist'),
	('cb80cbe8','@lib/jquery-ui'),
	('ced5feb9','@lib/velocity'),
	('d080efed','@app/web/assets/tablesettings/dist'),
	('d2f25151','@lib/jquery.payment'),
	('d3da0834','@app/web/assets/updateswidget/dist'),
	('d9aa81b2','@app/web/assets/utilities/dist'),
	('da83cb99','@craft/web/assets/editentry/dist'),
	('dd48a4f5','@app/web/assets/craftsupport/dist'),
	('de25c4d','@lib/xregexp'),
	('df5a09c4','@bower/jquery/dist'),
	('e49a49','@lib/fileupload'),
	('e5efeaf5','@craft/web/assets/matrixsettings/dist'),
	('e770c83c','@lib'),
	('eb1520fc','@app/web/assets/pluginstore/dist'),
	('ed604a5a','@app/web/assets/recententries/dist'),
	('f02d6dd7','@app/web/assets/cp/dist'),
	('f0caa231','@lib/element-resize-detector'),
	('f300dcf2','@app/web/assets/matrixsettings/dist'),
	('f758c95a','@vendor/craftcms/redactor/lib/redactor'),
	('f78fbce2','@craft/web/assets/craftsupport/dist'),
	('fa250999','@craft/web/assets/dashboard/dist'),
	('ff890b2f','@craft/web/assets/login/dist');
UNLOCK TABLES;


LOCK TABLES `searchindex` WRITE;
INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`) VALUES 
	(1,'username',0,1,' dgaebel '),
	(1,'firstname',0,1,''),
	(1,'lastname',0,1,''),
	(1,'fullname',0,1,''),
	(1,'email',0,1,' dgaebel trendyminds com '),
	(1,'slug',0,1,''),
	(2,'slug',0,1,' home '),
	(2,'title',0,1,' home '),
	(2,'field',1,1,''),
	(3,'field',2,1,' this is some tetxt '),
	(3,'field',1,1,''),
	(3,'slug',0,1,' image transforms '),
	(3,'title',0,1,' image transforms '),
	(4,'filename',0,1,' screenshot 2019 08 19 09 11 34 png '),
	(4,'extension',0,1,' png '),
	(4,'kind',0,1,' image '),
	(4,'slug',0,1,''),
	(4,'title',0,1,' screenshot 2019 08 19 09 11 34 '),
	(5,'field',3,1,' this is the entry text '),
	(5,'slug',0,1,' image transforms '),
	(5,'title',0,1,' image transforms '),
	(6,'filename',0,1,' screenshot 2019 08 19 09 11 34 png '),
	(6,'extension',0,1,' png '),
	(6,'kind',0,1,' image '),
	(6,'slug',0,1,''),
	(6,'title',0,1,' screenshot 2019 08 19 09 11 34 '),
	(7,'slug',0,1,' image transforms '),
	(7,'title',0,1,' image transforms '),
	(7,'field',3,1,' some text '),
	(8,'field',3,1,' hello world '),
	(8,'slug',0,1,' image transforms '),
	(8,'title',0,1,' image transforms '),
	(9,'filename',0,1,' screenshot 2019 08 17 11 33 14 png '),
	(9,'extension',0,1,' png '),
	(9,'kind',0,1,' image '),
	(9,'slug',0,1,''),
	(9,'title',0,1,' screenshot 2019 08 17 11 33 14 '),
	(10,'filename',0,1,' screenshot 2019 08 19 09 11 34 png '),
	(10,'extension',0,1,' png '),
	(10,'kind',0,1,' image '),
	(10,'slug',0,1,''),
	(10,'title',0,1,' screenshot 2019 08 19 09 11 34 '),
	(8,'field',4,1,''),
	(11,'field',3,1,' hello world '),
	(11,'slug',0,1,' image transforms '),
	(11,'title',0,1,' image transforms '),
	(12,'filename',0,1,' guitar png '),
	(12,'extension',0,1,' png '),
	(12,'kind',0,1,' image '),
	(12,'slug',0,1,''),
	(12,'title',0,1,' squier title '),
	(11,'field',5,1,' squier title stonybrook '),
	(13,'filename',0,1,' stonybrook png '),
	(13,'extension',0,1,' png '),
	(13,'kind',0,1,' image '),
	(13,'slug',0,1,''),
	(13,'title',0,1,' stonybrook '),
	(14,'field',5,1,''),
	(14,'field',3,1,''),
	(14,'slug',0,1,' craft '),
	(14,'title',0,1,' craft '),
	(15,'field',5,1,''),
	(15,'field',3,1,''),
	(15,'slug',0,1,' craft 1 '),
	(15,'title',0,1,' craft '),
	(16,'field',5,1,''),
	(16,'field',3,1,''),
	(16,'slug',0,1,' image transforms '),
	(16,'title',0,1,' image transforms '),
	(17,'field',5,1,''),
	(17,'field',3,1,''),
	(17,'slug',0,1,' image transforms 1 '),
	(17,'title',0,1,' image transforms '),
	(18,'field',5,1,''),
	(18,'field',3,1,''),
	(18,'slug',0,1,' image transforms '),
	(18,'title',0,1,' image transforms '),
	(19,'field',3,1,''),
	(19,'slug',0,1,' image transforms 1 '),
	(19,'title',0,1,' image transforms '),
	(19,'field',5,1,' stonybrook squier title '),
	(20,'field',5,1,''),
	(20,'field',3,1,''),
	(20,'slug',0,1,' image transforms '),
	(20,'title',0,1,' image transforms '),
	(21,'field',5,1,''),
	(21,'field',3,1,''),
	(21,'slug',0,1,' image transforms 1 '),
	(21,'title',0,1,' image transforms '),
	(22,'field',5,1,''),
	(22,'field',3,1,''),
	(22,'slug',0,1,' image transforms '),
	(22,'title',0,1,' image transforms '),
	(23,'field',5,1,''),
	(23,'field',3,1,''),
	(23,'slug',0,1,' image transforms 1 '),
	(23,'title',0,1,' image transforms '),
	(24,'field',5,1,''),
	(24,'field',3,1,''),
	(24,'slug',0,1,' image transforms '),
	(24,'title',0,1,' image transforms '),
	(25,'field',3,1,''),
	(25,'slug',0,1,' image transforms 1 '),
	(25,'title',0,1,' image transforms '),
	(26,'field',3,1,''),
	(26,'slug',0,1,' image transforms '),
	(26,'title',0,1,' image transforms '),
	(26,'field',5,1,''),
	(27,'field',5,1,''),
	(27,'field',3,1,''),
	(27,'slug',0,1,' image transforms 1 '),
	(27,'title',0,1,' image transforms '),
	(28,'field',3,1,''),
	(28,'slug',0,1,' image transforms '),
	(28,'title',0,1,' image transforms '),
	(28,'field',5,1,' stonybrook squier title '),
	(29,'slug',0,1,' controllers '),
	(29,'title',0,1,' controllers '),
	(29,'field',1,1,''),
	(29,'field',6,1,' stonybrook '),
	(31,'slug',0,1,''),
	(30,'field',7,1,' this is a heading from images row module '),
	(30,'slug',0,1,''),
	(30,'field',8,1,' stonybrook '),
	(32,'field',9,1,' stonybrook '),
	(32,'slug',0,1,'');
UNLOCK TABLES;


LOCK TABLES `sections` WRITE;
INSERT INTO `sections` (`id`, `structureId`, `name`, `handle`, `type`, `enableVersioning`, `propagateEntries`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES 
	(1,NULL,'Home','home','single',1,1,'2019-06-17 17:16:56','2020-01-03 17:09:03',NULL,'6ea80f24-bc86-4c5e-aa70-8d6079116ff2'),
	(2,NULL,'Image Transforms','imageTransforms','single',1,1,'2019-08-19 15:57:39','2019-08-19 20:26:23',NULL,'f52db722-5a93-4a55-92f0-85859fa0f486'),
	(3,NULL,'Controllers','controllers','single',1,1,'2020-01-29 19:37:56','2020-01-29 20:03:22',NULL,'b40e8623-76b5-4398-a5f4-6f50c3b71ce1');
UNLOCK TABLES;


LOCK TABLES `sections_sites` WRITE;
INSERT INTO `sections_sites` (`id`, `sectionId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `enabledByDefault`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,1,1,1,'__home__','index',1,'2019-06-17 17:16:56','2020-01-03 17:09:03','b972369f-f0ef-4005-85fa-18219be7965b'),
	(2,2,1,1,'/{slug}','image-transforms/index.html',1,'2019-08-19 15:57:39','2019-08-19 20:26:23','6214cea8-9fe6-49d6-b233-259125efc36d'),
	(3,3,1,1,'/{slug}','controllers/index',1,'2020-01-29 19:37:56','2020-01-29 20:03:22','57a4cef4-a136-45bc-aa79-7a04730eebda');
UNLOCK TABLES;


LOCK TABLES `sequences` WRITE;
UNLOCK TABLES;


LOCK TABLES `sessions` WRITE;
INSERT INTO `sessions` (`id`, `userId`, `token`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,1,'U2PAwIF8KvIO9WNAQNvh8DAhWpO7lXKsXSTqhYvShBFPxSbsnYZFySncTl4NF2v1y_EGJLqnWzC_ZhfpXfqPfbUM4AA5TmVzr3vh','2019-05-23 15:26:22','2019-05-23 15:49:03','643817d7-d57b-4756-9648-61e0ac32e279'),
	(2,1,'CBShLERIYFqldtv3MkZ-uYDNlKt_QAO2WG7DYTPtYLcGy_t9UCiYIC5d8xk8eQyV3WrKK-AySQGb8w4i70yNGcF1p1RRVopXRIl3','2019-06-17 16:42:09','2019-06-17 17:19:45','0ca0ba4a-0ed2-4daa-8907-d14918d91a5b'),
	(3,1,'FDQAsa3D0_cumwPEz7XViWTKOixtfjS8O4qUP1W3aPqgVr_t1Y9rrbH6IQKQ_IQpcpR3_6GMMsn-HVhpMEKVgieKeW96pt4cdbzj','2019-08-19 15:32:20','2019-08-19 16:16:31','fb6b010d-defc-445d-b16a-ea7411d5a5ab'),
	(4,1,'QfVsotUUecWm5j8fsBOnTUFCXztoSQHGD9GiNHWpTwBgknmP6RmvoPCL8C91VWZ2GcNxAVipD3OgzHp0P0Kycac2o6rB_jLUUwtz','2019-08-19 17:16:35','2019-08-19 20:32:47','854ddede-7000-4e76-88b4-f677251e1037'),
	(5,1,'aG_iHhpjVTGHqEgzhi-g4nOOEajni-MDbUg1RwzrwuXbPE8-sBgiVHzBWXQ1S3s00Rdg_38gm1lPMt_gi79Yfwv_8vfXzMcaYgBO','2020-01-03 16:48:45','2020-01-03 17:20:17','d8b8b00b-eea6-4d0f-9b78-e35973f3fa5c'),
	(6,1,'az6O_UEVb3AA_Ake0cHLsodnJqB4A877QWWBx-N0_rKRe_4H1OdMKJ2Ob9DjgE8vq3-euudYetffgzVwJOh4v3AmHk-r_vshT6qK','2020-01-03 18:20:32','2020-01-03 18:20:32','2876ebf7-fdc9-4441-bb08-d5e2dba29d2a'),
	(7,1,'3pv5Z9K_9PbImxi5EeiSI3k8YLxJ7uN1aJEpbqSlRePs56zphavQQEBUU675uQK1y1pjZxITFZ_Q-HsWH6rGhEmNI6IGcdyF69X7','2020-01-29 19:06:51','2020-01-29 20:20:34','485cbff5-5185-40b5-97ac-cdeb26b299e3'),
	(8,1,'VgRFRmXakm-W1OrYfnsqXjURxEaaBQpNmdlnb1es69Ky0RY8VhaaaB9SubdZeaE11IV33ozStdlAVBkvSFNCDo9moYtesuy7fOHA','2020-01-29 19:45:52','2020-01-29 20:11:34','10611c3d-4e14-49c8-91cd-38b4f5a5379e'),
	(9,1,'DKWJixKcdIwwNgc2bLI6lR40EytjmHj1RyL5a_1qdc1oSmBYMt2lklycS2iT2OkvygQTi7Mk8pv2yVxN_gBBR7RDi0AiOa-HGYEk','2020-01-30 16:10:41','2020-01-30 17:16:30','dfd32e5d-d916-4c05-94ef-84122c513aa9'),
	(10,1,'AlBUV9hhHrWcTH0bhGzhL6sNsfU6BMWhe-gTfEdQA2fQMtSlC5CC89i1JXfEPFnCEOFalYeJ2vNuHjwHYS7H1dkzkmRZ4MYkH1nM','2020-05-19 18:49:06','2020-05-20 20:02:15','53f179ca-6b24-4e91-87b8-b364bc05b52e'),
	(11,1,'B50c1u8-IRnTF9kZuw-4n2pmBt3MBf7mbcb-UHHdfKVAo6l95256O5DKtF1nS6ztJA5ImA0k8palPGSTwXiKx-_LkCJ6ViGxsAIB','2020-05-20 20:02:43','2020-05-21 13:48:07','96ba821d-e189-4624-9c31-b9b806197af4'),
	(12,1,'W8Wygw8kym_Agd_9mRDinGiBrroQd_nhovVznrkjQw5f3XX26U8er-AAp3aRzblYq-gpjQROlXXVYpCciYbeilOuw4KS_R8rqJCp','2020-05-21 13:48:20','2020-05-21 15:35:06','eb82cb97-1c11-413f-98dc-d4b69d6b1a64'),
	(13,1,'iGXOaqVqxLWj1PEf5atXrJlrwPSZLOtkTJYx3k6pel1s0p1iSRerRnkQqUxdNiMvWITuubSvPnmOjZ0MvNumnhBOJjpVTQstgt63','2020-05-21 16:35:11','2020-05-21 16:35:11','f16a3e27-78b7-4109-972d-5f17bf4258ae'),
	(14,1,'txMwKCFiceoJ_Ops24FPcC5mrzR23ffhy7jfeKXjnks-Ymk2wREG691vsegy-VB8IgOtHaFJ4UE1InLYJPsTn6_9XDQfO6kQak8D','2020-05-21 17:35:15','2020-05-21 18:38:42','45879449-bdd6-49c4-965f-82534b3c90ba'),
	(15,1,'C2OuNH9JpWlf4IDxHOVSmWAbDJt_5LknrdT5S0hVz9EoVZUsPFN4E7ZUBjQESzO01EeYxQ5vjbZsRil5GHcON3zZJpCTIVoQY2sy','2020-05-21 19:38:45','2020-05-26 13:17:23','e5309b98-1d46-403f-b07c-383facd7473d'),
	(16,1,'IdYFatoZ5rPAKsC4-YRrMULG431QZL4THuha_frrqaLtcEKTO2PidW3Vljs_FjFahrYewNUCswt4Ye1VWq8llsBAOoCxKqlgu_0Z','2020-05-26 13:17:37','2020-05-26 15:24:59','1f088357-fb55-4266-bb3c-e2eb35dd12f4'),
	(17,1,'61YRjkysqBQHo0U8EPvmK0Fvj72o9C8ZK1c4H7Qp7TE69hqH7E_Ir3Oc4brmfqGFV7ToqJ88ckHs_mfLMBqq5PLrWe8uZtiFiLOb','2020-05-26 15:25:13','2020-05-28 12:56:29','6033d9eb-8220-4d01-b3e4-04841d122d53'),
	(18,1,'emBt9LiQs8JocjqfL2px_2We94DyxML2mqQojzf3RNJjEXkPmxPaBOxMcCJZIJzhGqaJ0Ig-uoYgTvkfPQ4VFbdX-yk5IyFtvFKY','2020-05-28 12:56:42','2020-05-28 13:01:27','50008b89-fc02-4578-b881-0af4b2fbf5cf');
UNLOCK TABLES;


LOCK TABLES `shunnedmessages` WRITE;
UNLOCK TABLES;


LOCK TABLES `sitegroups` WRITE;
INSERT INTO `sitegroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES 
	(1,'Craft','2019-05-23 15:26:20','2019-05-23 15:26:20',NULL,'e39f71de-1042-4704-a00b-8c0259b85b9f');
UNLOCK TABLES;


LOCK TABLES `sites` WRITE;
INSERT INTO `sites` (`id`, `groupId`, `primary`, `name`, `handle`, `language`, `hasUrls`, `baseUrl`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES 
	(1,1,1,'Craft','default','en-US',1,'$DEFAULT_SITE_URL',1,'2019-05-23 15:26:20','2019-05-23 15:26:20',NULL,'d75216f4-5e35-406f-a4e9-13e077287499');
UNLOCK TABLES;


LOCK TABLES `stc_1_images` WRITE;
INSERT INTO `stc_1_images` (`id`, `elementId`, `siteId`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,32,1,'2020-01-29 19:59:24','2020-01-29 20:03:23','816bee14-ec51-4c93-8426-6c372afd14e6');
UNLOCK TABLES;


LOCK TABLES `structures` WRITE;
UNLOCK TABLES;


LOCK TABLES `structureelements` WRITE;
UNLOCK TABLES;


LOCK TABLES `supertableblocktypes` WRITE;
INSERT INTO `supertableblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,8,6,'2020-01-29 19:58:59','2020-01-29 19:58:59','bfa73f7f-ca2e-4baa-9ed1-54ba895f163f');
UNLOCK TABLES;


LOCK TABLES `supertableblocks` WRITE;
INSERT INTO `supertableblocks` (`id`, `ownerId`, `ownerSiteId`, `fieldId`, `typeId`, `sortOrder`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(32,30,NULL,8,1,1,NULL,'2020-01-29 19:59:24','2020-01-29 20:03:23','d5b120a6-48e9-4455-8867-c208b2a2b87a');
UNLOCK TABLES;


LOCK TABLES `systemmessages` WRITE;
UNLOCK TABLES;


LOCK TABLES `taggroups` WRITE;
UNLOCK TABLES;


LOCK TABLES `tags` WRITE;
UNLOCK TABLES;


LOCK TABLES `templatecaches` WRITE;
UNLOCK TABLES;


LOCK TABLES `templatecacheelements` WRITE;
UNLOCK TABLES;


LOCK TABLES `templatecachequeries` WRITE;
UNLOCK TABLES;


LOCK TABLES `tokens` WRITE;
INSERT INTO `tokens` (`id`, `token`, `route`, `usageLimit`, `usageCount`, `expiryDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(8,'4tGgwPNuhgnKQ_m7ca_g9n8BIrL22ZyG','["live-preview/preview",{"previewAction":"entries/preview-entry","userId":"1"}]',NULL,NULL,'2020-05-20 18:49:21','2020-05-19 18:49:21','2020-05-19 18:49:21','794dd73b-b3f1-4e98-ad60-0461af1aeaab');
UNLOCK TABLES;


LOCK TABLES `usergroups` WRITE;
UNLOCK TABLES;


LOCK TABLES `usergroups_users` WRITE;
UNLOCK TABLES;


LOCK TABLES `userpermissions` WRITE;
UNLOCK TABLES;


LOCK TABLES `userpermissions_usergroups` WRITE;
UNLOCK TABLES;


LOCK TABLES `users` WRITE;
INSERT INTO `users` (`id`, `username`, `photoId`, `firstName`, `lastName`, `email`, `password`, `admin`, `locked`, `suspended`, `pending`, `lastLoginDate`, `lastLoginAttemptIp`, `invalidLoginWindowStart`, `invalidLoginCount`, `lastInvalidLoginDate`, `lockoutDate`, `hasDashboard`, `verificationCode`, `verificationCodeIssuedDate`, `unverifiedEmail`, `passwordResetRequired`, `lastPasswordChangeDate`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,'dgaebel',NULL,NULL,NULL,'dgaebel@trendyminds.com','$2y$13$gm54BZeBGgdxb0K2KE38CeA3k/YJS5MrXKvadMvtze9b7gZvnU4BS',1,0,0,0,'2020-05-28 12:56:42',NULL,NULL,NULL,'2020-01-30 16:10:24',NULL,1,NULL,NULL,NULL,0,'2019-05-23 15:26:22','2019-05-23 15:26:22','2020-05-28 12:56:42','0790d326-3daf-4963-b9c1-79f39cacf202');
UNLOCK TABLES;


LOCK TABLES `userpermissions_users` WRITE;
UNLOCK TABLES;


LOCK TABLES `userpreferences` WRITE;
INSERT INTO `userpreferences` (`userId`, `preferences`) VALUES 
	(1,'{"language":"en-US"}');
UNLOCK TABLES;


LOCK TABLES `volumes` WRITE;
INSERT INTO `volumes` (`id`, `fieldLayoutId`, `name`, `handle`, `type`, `hasUrls`, `url`, `settings`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`) VALUES 
	(1,3,'uploads','uploads','craft\\volumes\\Local',1,'$IMAGES_URL','{"path":"$IMAGES_URL"}',1,'2019-08-19 17:47:10','2019-08-19 18:16:00','2019-08-19 18:20:52','d5202aac-e455-463b-b8a3-2ab65be469b4'),
	(2,NULL,'uploads','uploads','craft\\volumes\\Local',0,NULL,'{"path":"$IMAGES_URL"}',2,'2019-08-19 18:30:44','2019-08-19 18:34:08','2019-08-19 18:38:44','44a36c92-4fcf-48ac-873a-60cae14e5cf1'),
	(3,NULL,'uploads','uploads','craft\\volumes\\Local',1,'/images','{"path":"$LOCAL_ASSETS_PATH"}',3,'2019-08-19 18:39:19','2019-08-19 19:04:48',NULL,'c416baed-fb8d-4319-8775-fe5d7e7c3d53');
UNLOCK TABLES;


LOCK TABLES `volumefolders` WRITE;
INSERT INTO `volumefolders` (`id`, `parentId`, `volumeId`, `name`, `path`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,NULL,NULL,'Temporary source',NULL,'2019-08-19 16:08:55','2019-08-19 16:08:55','f1f65ff6-a296-40bf-9d72-204a14413f4f'),
	(2,1,NULL,'user_1','user_1/','2019-08-19 16:08:55','2019-08-19 16:08:55','09c903e3-d143-4d75-9acb-1cbf5c9c6f61'),
	(3,NULL,1,'uploads','','2019-08-19 17:47:10','2019-08-19 18:16:00','64045bfe-6367-474b-b733-3e71c638f448'),
	(4,NULL,2,'uploads','','2019-08-19 18:30:44','2019-08-19 18:34:08','1f373d18-114f-454c-93be-83bc74253f8a'),
	(5,NULL,3,'uploads','','2019-08-19 18:39:19','2019-08-19 19:04:48','23dc0984-8253-472a-8134-d03aa2c1f49e');
UNLOCK TABLES;


LOCK TABLES `widgets` WRITE;
INSERT INTO `widgets` (`id`, `userId`, `type`, `sortOrder`, `colspan`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`) VALUES 
	(1,1,'craft\\widgets\\RecentEntries',1,NULL,'{"section":"*","siteId":"1","limit":10}',1,'2019-05-23 15:26:23','2019-05-23 15:26:23','b0740bf6-f134-4710-a73b-a6f706cf1544'),
	(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2019-05-23 15:26:23','2019-05-23 15:26:23','bfda5818-451e-4032-bc95-a6dfc3a52260'),
	(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2019-05-23 15:26:23','2019-05-23 15:26:23','bd63b81d-86c7-4ad5-9b29-7c66ec009071'),
	(4,1,'craft\\widgets\\Feed',4,NULL,'{"url":"https://craftcms.com/news.rss","title":"Craft News","limit":5}',1,'2019-05-23 15:26:23','2019-05-23 15:26:23','a28c27d7-29f9-4b67-81dc-4a5943dc8271');
UNLOCK TABLES;






SET FOREIGN_KEY_CHECKS = @ORIG_FOREIGN_KEY_CHECKS;

SET UNIQUE_CHECKS = @ORIG_UNIQUE_CHECKS;

SET @ORIG_TIME_ZONE = @@TIME_ZONE;
SET TIME_ZONE = @ORIG_TIME_ZONE;

SET SQL_MODE = @ORIG_SQL_MODE;



# Export Finished: September 2, 2020 at 5:55:22 PM EDT

